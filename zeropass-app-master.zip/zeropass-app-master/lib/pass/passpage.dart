import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PassPage extends StatefulWidget {
  @override
  _PassPageState createState() => _PassPageState();
}

class _PassPageState extends State<PassPage> {
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final dbRef = FirebaseDatabase.instance.reference();
  GlobalKey globalKey = new GlobalKey();

  String token, district, taluk;
  String dataString;
  Color color;

  bool isLoading = true;

  _getExtras() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    district = prefs.getString('district');
    taluk = prefs.getString('taluk');
    if (district != null) {
      _getColor();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  _getColor() async {
    dbRef
        .child('Regions/$district/$taluk/Users/$token')
        .onValue
        .listen((event) {
      var containment = event.snapshot.value['Containment'];
      var quarantine = event.snapshot.value['Quarantine'];
      if (quarantine == true) {
        color = Colors.red.shade800;
      } else if (containment == true) {
        color = Colors.blue.shade800;
      } else {
        color = Colors.teal.shade800;
      }
      Map data = {
        'token': token,
        'dst': district,
        'tlk': taluk,
        'timestamp': DateTime.now().toString()
      };
      dataString = json.encode(data);
      setState(() {
        isLoading = false;
      });
    });
  }

  _getDeviceToken() async {
    var t = await _messaging.getToken();
    token = t.toString();
    _getExtras();
  }

  @override
  void initState() {
    _getDeviceToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'View My Pass',
          style: TextStyle(
            fontSize: 24,
            fontFamily: "RussoOne",
            color: Colors.black.withOpacity(0.8),
            letterSpacing: 1.3,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '- Color Indicator -',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10.0,
            ),
            Wrap(
              direction: Axis.horizontal,
              children: [
                Icon(
                  Icons.bookmark,
                  color: Colors.red.shade800,
                ),
                Text('Person in Quarantine'),
              ],
            ),
            Wrap(
              direction: Axis.horizontal,
              children: [
                Icon(
                  Icons.bookmark,
                  color: Colors.blue.shade800,
                ),
                Text('Person from Containment Zone'),
              ],
            ),
            Wrap(
              direction: Axis.horizontal,
              children: [
                Icon(
                  Icons.bookmark,
                  color: Colors.teal.shade800,
                ),
                Text('Person is Safe'),
              ],
            ),
            SizedBox(
              height: 20.0,
            ),
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: Text(
                  '- Scan QR using ZeroPass App to verify your pass.\n- Pass validity is 10 minutes'),
            ),
            SizedBox(
              height: 10.0,
            ),
            isLoading
                ? Container(
                    height: MediaQuery.of(context).size.width - 16.0,
                    child: Center(
                      child: CircularProgressIndicator(
//                backgroundColor: Colors.white,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                      ),
                    ),
                  )
                : dataString == null
                    ? Container(
                        height: MediaQuery.of(context).size.width - 16.0,
                        child: Center(
                          child: Text(
                            'Add your resident address before generating pass.',
                            style: TextStyle(
                                color: Colors.red.shade800,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      )
                    : RepaintBoundary(
                        key: globalKey,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(16.0)),
                          height: MediaQuery.of(context).size.width - 16.0,
                          child: Center(
                            child: QrImage(
                              backgroundColor: Colors.white,
                              foregroundColor: color,
                              data: dataString,
                              size: 0.5 * MediaQuery.of(context).size.width,
                              errorStateBuilder:
                                  (BuildContext context, Object error) {
                                return Text(error);
                              },
                            ),
                          ),
                        ),
                      ),
            SizedBox(
              height: 10.0,
            ),
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: Text(
                  'Please check basic information from status board in General Info page.'),
            ),
          ],
        ),
      ),
    );
  }
}
