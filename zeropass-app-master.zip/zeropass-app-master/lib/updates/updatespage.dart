import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:esys_flutter_share/esys_flutter_share.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UpdatesPage extends StatefulWidget {
  @override
  _UpdatesPageState createState() => _UpdatesPageState();
}

class _UpdatesPageState extends State<UpdatesPage> {
  final dbRef = FirebaseDatabase.instance.reference();
  StreamSubscription<Event> _counterSubscription1;
  StreamSubscription<Event> _counterSubscription2;

  String mob, username;

  List adsList = [];
  List articles = [];

  _getLocalData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    mob = prefs.getString('mob');
    username = prefs.getString('username');
    _getArticles();
  }

  _getAdds() async {
    _counterSubscription1 = dbRef.child('Adds').onValue.listen((event) {
      adsList = [];
      Map data = event.snapshot.value;
      data.forEach((key, value) {
        adsList.add(value);
      });
      setState(() {});
    });
  }

  _getArticles() async {
    _counterSubscription2 = dbRef.child('Articles').onValue.listen((event) {
      var data = event.snapshot.value;
      articles = data.toList();
      setState(() {});
    });
  }

  @override
  void initState() {
    _getAdds();
    _getLocalData();
    super.initState();
  }

  @override
  void dispose() {
    if (_counterSubscription1 != null) {
      _counterSubscription1.cancel();
    }
    if (_counterSubscription2 != null) {
      _counterSubscription2.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          adsPreview(),
          SizedBox(
            height: 24.0,
          ),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              '- Trending Articles -',
              style: TextStyle(
                color: Colors.black.withOpacity(0.8),
                fontWeight: FontWeight.bold,
                fontSize: 16.0,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(
            height: 8.0,
          ),
          updates(),
          SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  adsPreview() {
    return Container(
      height: 150,
      child: Swiper(
        itemCount: adsList.length,
        index: 0,
        scrollDirection: Axis.horizontal,
        loop: true,
        fade: 0.5,
        viewportFraction: 0.6,
        scale: 0.6,
        autoplay: true,
//              pagination: SwiperPagination(
//                margin: EdgeInsets.all(0.0),
//                builder: DotSwiperPaginationBuilder(
//                  color: Colors.white,
//                  activeColor: Colors.black.withOpacity(0.8),
//                ),
//              ),
        controller: SwiperController(),
        control: SwiperControl(color: Colors.white),
        itemBuilder: (BuildContext context, int index) {
          return Container(
            margin: EdgeInsets.symmetric(vertical: 15.0),
            padding: EdgeInsets.all(4.0),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
//                      border: Border.all(width: 0, color: Colors.white),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  offset: Offset(4.0, 2.0),
                  blurRadius: 4.0,
                ),
              ],
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Image.network(
                adsList[index],
                fit: BoxFit.fill,
              ),
            ),
          );
        },
      ),
    );
  }

  updates() {
    return ListView.builder(
      shrinkWrap: true,
      primary: false,
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      itemCount: articles.length,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          margin: EdgeInsets.symmetric(vertical: 4.0),
          padding: EdgeInsets.only(bottom: 8.0),
//          height: 300,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                offset: Offset(2.0, 2.0),
                blurRadius: 4.0,
              ),
            ],
          ),
          child: Column(
            children: [
              SizedBox(height: 10.0),
              ListTile(
                title: Text(articles[(articles.length) - index - 1]['Title']),
                subtitle: Text(
                    articles[(articles.length) - index - 1]['Description']),
                trailing: IconButton(
                  icon: Icon(Icons.share),
                  onPressed: () async {
                    var request = await HttpClient().getUrl(Uri.parse(
                        articles[(articles.length) - index - 1]['Image']));
                    var response = await request.close();
                    Uint8List bytes =
                        await consolidateHttpClientResponseBytes(response);
                    await Share.files(
                        articles[(articles.length) - index - 1]['Title'],
                        {
                          'article_zeropass${articles[(articles.length) - index - 1]['Format']}':
                              bytes.buffer.asUint8List()
                        },
                        '*/*',
                        text:
                            '${articles[(articles.length) - index - 1]['Title']}\n${articles[(articles.length) - index - 1]['Description']}');
                  },
                ),
              ),
              SizedBox(height: 5.0),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20.0),
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.0),
                  child: Image.network(
                    articles[(articles.length) - index - 1]['Image'],
                    fit: BoxFit.fill,
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
//              Row(
//                mainAxisAlignment: MainAxisAlignment.spaceAround,
//                children: [
//                  Icon(Icons.thumb_up),
////                  Icon(Icons.chat_bubble_outline),
//                  IconButton(
//                    icon: Icon(Icons.share),
//                    onPressed: () async {
//                      var request = await HttpClient().getUrl(Uri.parse(
//                          articles[(articles.length) - index - 1]['Image']));
//                      var response = await request.close();
//                      Uint8List bytes =
//                          await consolidateHttpClientResponseBytes(response);
//                      await Share.files(
//                          articles[(articles.length) - index - 1]['Title'],
//                          {
//                            'article_zeropass${articles[(articles.length) - index - 1]['Format']}':
//                                bytes.buffer.asUint8List()
//                          },
//                          '*/*',
//                          text:
//                              '${articles[(articles.length) - index - 1]['Title']}\n${articles[(articles.length) - index - 1]['Description']}');
//                    },
//                  ),
//                ],
//              ),
            ],
          ),
        );
      },
    );
  }
}
