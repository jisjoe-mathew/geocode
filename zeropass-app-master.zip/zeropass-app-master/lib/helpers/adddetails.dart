import 'package:shared_preferences/shared_preferences.dart';

class AddDetails {
  basicDetails(
      String username, String address, String aadharID, String mob) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', username);
    await prefs.setString('address', address);
    await prefs.setString('aadharID', aadharID);
    await prefs.setString('mob', mob);
    print('successfully added basic details to local storage');
  }

  locationDetails(String timeOfLocation, bool isLocationAdded, String district,
      String taluk) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('timeOfLocation', timeOfLocation);
    await prefs.setBool('isLocationAdded', isLocationAdded);
    await prefs.setString('district', district);
    await prefs.setString('taluk', taluk);
    print('successfully added location details to local storage');
  }

  setPreviousDetails(String timeOfLocation, bool isLocationAdded,
      String district, String taluk) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('timeOfLocation', timeOfLocation);
    await prefs.setBool('isLocationAdded', isLocationAdded);
    await prefs.setString('district', district);
    await prefs.setString('taluk', taluk);
  }

  quarantine(bool isQuarantine) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isQuarantine', isQuarantine);
  }
}
