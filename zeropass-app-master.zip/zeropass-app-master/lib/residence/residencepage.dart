import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/helpers/adddetails.dart';

class ResidencePage extends StatefulWidget {
  @override
  _ResidencePageState createState() => _ResidencePageState();
}

class _ResidencePageState extends State<ResidencePage> {
  Completer<GoogleMapController> _googleMapController = Completer();
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final dbRef = FirebaseDatabase.instance.reference();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  List<Marker> markers = [];
  LatLng latlng = LatLng(8.506005, 76.962491);
  bool isLoading = false;
  bool isLocationAdded;
  LatLng checkLatLong;
  String username,
      address,
      aadharID,
      mob,
      timeOfLocation,
      token,
      taluk,
      district;
  Position position;
  LatLng latLong;

  _getDeviceToken() async {
    var t = await _messaging.getToken();
    token = t.toString();
  }

  _getRegion(Position position) async {
    var url =
        'https://api.tomtom.com/search/2/reverseGeocode/${position.latitude}%2C%20${position.longitude}.json?key=W992tkrTvKiv0nidyYUfYP6wymvhTiNb';
    var response = await http.get(url);
    var data = json.decode(response.body);
    print(data['addresses'][0]['address']['municipality']);

    taluk = data['addresses'][0]['address']['municipality'];
    district = data['addresses'][0]['address']['countrySecondarySubdivision'];
    print(district);
    print(taluk);
  }

  _getPosition() async {
    position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    _getRegion(position);
    _changeCameraPosition(position);
    checkLatLong = LatLng(position.latitude, position.longitude);
    latLong = LatLng(position.latitude, position.longitude);
    print(latLong);
    markers = [];
    markers.add(
      Marker(
        markerId: MarkerId(position.toString()),
        draggable: true,
        onDragEnd: (dragEndPosition) {
          latLong = dragEndPosition;
          print(latLong);
        },
        position: LatLng(position.latitude, position.longitude),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      ),
    );
    setState(() {
      isLoading = false;
    });
  }

  _changeCameraPosition(Position position) async {
    await _googleMapController.future.then((value) {
      value.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 18.0,
        ),
      ));
    });
  }

  _getLocalDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    username = prefs.getString('username');
    address = prefs.getString('address');
    aadharID = prefs.getString('aadharID');
    mob = prefs.getString('mob');
    isLocationAdded = prefs.getBool('isLocationAdded');
    timeOfLocation = prefs.getString('timeOfLocation');
  }

  _confirmValidation() async {
    double distanceInMeters = await Geolocator().distanceBetween(
        checkLatLong.latitude,
        checkLatLong.longitude,
        latLong.latitude,
        latLong.longitude);
    if (distanceInMeters > 1000) {
      turnOfLoading();
      showSnackBar(Colors.red,
          'Cannot add location !\nYou can move marker maximum within 1Km radius');
    } else if (isLocationAdded == null && latLong != null) {
      _createUserDB();
    } else if (((DateTime.now()).difference(DateTime.parse(timeOfLocation)))
                .inDays >
            7 &&
        latLong != null) {
      _changeResidenceInDB();
    } else {
      turnOfLoading();
      showSnackBar(Colors.red,
          'Try After ${7 - (((DateTime.now()).difference(DateTime.parse(timeOfLocation))).inDays)} Days!');
    }
  }

  _createUserDB() {
    print('_createUserDB');
    timeOfLocation = DateTime.now().toString();
    dbRef.child('Regions/$district/$taluk/Users/$token').update({
      'AadharID': aadharID,
      'Address': address,
      'Lat': latLong.latitude,
      'Long': latLong.longitude,
      'Mob': mob,
      'Name': username,
      'Quarantine': false,
      'Status': 'None',
      'Tol': timeOfLocation,
      'Quarantine': false,
      'Containment': false,
      'Breaks': 0,
    }).then((value) {
      dbRef.child('Regions/$district/$taluk/Tokens').update({
        mob: token,
      }).then((value) {
        dbRef.child('PassID/$mob').update({
          "Token": token,
          "District": district,
          "Taluk": taluk,
          "Tol": timeOfLocation,
        }).then((value) async {
          await AddDetails()
              .locationDetails(timeOfLocation, true, district, taluk);
          isLocationAdded = true;
          turnOfLoading();
          showSnackBar(Colors.teal, 'Successful');
        }).catchError((e) {
          print(e);
          turnOfLoading();
        });
      }).catchError((e) {
        print(e);
        turnOfLoading();
      });
    }).catchError((e) {
      print(e);
      turnOfLoading();
    });
  }

  _changeResidenceInDB() {
    print('_changeResidenceInDB');

    dbRef.child('PassID/$mob').once().then((snapshot) {
      String dst = snapshot.value['District'];
      String tlk = snapshot.value['Taluk'];
      String oldToken = snapshot.value['Token'];
      dbRef.child('Regions/$dst/$tlk/Users/$oldToken').once().then((snapshot) {
        Map data = snapshot.value;
        print(data);
        timeOfLocation = DateTime.now().toString();
        dbRef.child('Regions/$dst/$tlk/Users/$token').update({
          'Status': data['Status'],
          'Tol': timeOfLocation,
          'Breaks': data['Breaks'],
          'Mob': data['Mob'],
          'AadharID': data['AadharID'],
          'Address': data['Address'],
          'Long': latLong.longitude,
          'Quarantine': data['Quarantine'],
          'Lat': latLong.latitude,
          'Containment': data['Containment'],
          'Name': data['Name'],
        }).then((value) {
          dbRef.child('PassID/$mob').update({
            "Token": token,
            "District": district,
            "Taluk": taluk,
            "Tol": timeOfLocation,
          }).then((value) async {
            await AddDetails()
                .locationDetails(timeOfLocation, true, district, taluk);
            isLocationAdded = true;
            turnOfLoading();
            showSnackBar(Colors.teal, 'Successful');
          }).catchError((e) {
            print(e);
            turnOfLoading();
          });
          if (tlk != taluk) {
            dbRef
                .child('Regions/$dst/$tlk/Users/$oldToken')
                .remove()
                .catchError((e) {
              print(e);
              turnOfLoading();
            });
          }
        }).catchError((e) {
          print(e);
          turnOfLoading();
        });
      }).catchError((e) {
        print(e);
        turnOfLoading();
      });
    }).catchError((e) {
      print(e);
      turnOfLoading();
    });
  }

  turnOfLoading() {
    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    _getDeviceToken();
    _getLocalDetails();
    _getPosition();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
            elevation: 0.0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(
              'Edit Residence',
              style: TextStyle(
                fontSize: 24,
                fontFamily: "RussoOne",
                color: Colors.black.withOpacity(0.8),
                letterSpacing: 1.3,
              ),
            ),
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Read This Before Setting Your Resident Location',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 4.0,
                ),
                Text(
                  "Set your resident location from your residence.\nYour residence location is important for generating pass.\nYou can drag marker and set location manually.\nTo get accurate position of your residence, turn on GPS (or Location Service), then click reset.\nZoom the map to get correct center of your residence.\n",
                ),
                Container(
                  height: MediaQuery.of(context).size.height / 2.5,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        offset: Offset(2.0, 2.0),
                        blurRadius: 4.0,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16.0),
                    child: GoogleMap(
                      initialCameraPosition:
                          CameraPosition(target: latlng, zoom: 18.0),
                      markers: Set.from(markers),
                      mapType: MapType.normal,
                      onMapCreated: (GoogleMapController googleMapController) {
                        _googleMapController.complete(googleMapController);
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Flexible(
                      flex: 1,
                      child: MaterialButton(
                        minWidth: MediaQuery.of(context).size.width / 3,
                        color: Colors.red.shade50,
                        child: Text('Reset'),
                        onPressed: () {
                          setState(() {
                            isLoading = true;
                          });
                          _getPosition();
                        },
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: MaterialButton(
                        minWidth: MediaQuery.of(context).size.width / 3,
                        color: Colors.teal.shade50,
                        child: Text('Confirm'),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext dialogContext) {
                              return confirmDialog();
                            },
                          );
                        },
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
        Visibility(
          visible: isLoading,
          child: WillPopScope(
            onWillPop: () async {
              if (isLoading) {
                return false;
              } else {
                return true;
              }
            },
            child: Scaffold(
              backgroundColor: Colors.black26,
              body: Center(
                child: CircularProgressIndicator(
//                backgroundColor: Colors.white,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  confirmDialog() {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
      title: Text('Confirm Your Resident Location'),
      content: Text('Once confirmed you can only change it after one week'),
      actions: <Widget>[
        MaterialButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.red.shade800),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        MaterialButton(
          child: Text(
            'CONFIRM',
            style: TextStyle(color: Colors.teal.shade800),
          ),
          onPressed: () async {
            setState(() {
              isLoading = true;
            });
            _confirmValidation();
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  showSnackBar(Color color, String text) {
    return _scaffoldKey.currentState.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: ContinuousRectangleBorder(
            borderRadius: BorderRadius.circular(30.0)),
        content: Text(
          text,
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }
}
