import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:latlong/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/routemap/raised_gradient_button.dart';

import 'dataModel.dart';

SharedPreferences localStorage;
String uid,
    name,
    phone,
    gender,
    yob,
    gname,
    house,
    lm,
    vtc,
    po,
    dist,
    state,
    pc;

class FilePickerDemo extends StatefulWidget {
  @override
  _FilePickerDemoState createState() => new _FilePickerDemoState();
}

List<Patient> list = new List<Patient>();
String contentss = "";
int count = 0;

class _FilePickerDemoState extends State<FilePickerDemo> {
  String _fileName;
  String _path;
  File file;
  Map<String, String> _paths;
  String _extension;
  bool _loadingPath = false;
  bool _multiPick = false;
  bool loading = false;
  FileType _pickingType;
  TextEditingController _controller = new TextEditingController();

  @override
  void initState() {
    super.initState();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
      uid = localStorage.getString("uid") != null
          ? localStorage.getString("uid")
          : "";
      name = localStorage.getString("name") != null
          ? localStorage.getString("name")
          : "";
      phone = localStorage.getString("phone") != null
          ? localStorage.getString("phone")
          : "";
      gender = localStorage.getString("gender") != null
          ? localStorage.getString("gender")
          : "";
      yob = localStorage.getString("yob") != null
          ? localStorage.getString("yob")
          : "";
      gname = localStorage.getString("gname") != null
          ? localStorage.getString("gname")
          : "";
      house = localStorage.getString("house") != null
          ? localStorage.getString("house")
          : "";
      lm = localStorage.getString("lm") != null
          ? localStorage.getString("lm")
          : "";
      vtc = localStorage.getString("vtc") != null
          ? localStorage.getString("vtc")
          : "";
      po = localStorage.getString("po") != null
          ? localStorage.getString("po")
          : "";
      dist = localStorage.getString("dist") != null
          ? localStorage.getString("dist")
          : "";
      state = localStorage.getString("state") != null
          ? localStorage.getString("state")
          : "";
      pc = localStorage.getString("pc") != null
          ? localStorage.getString("pc")
          : "";
      await request_offers();
    }

    // initShared();
    _controller.addListener(() => _extension = _controller.text);

    setState(() {});
  }

  void _openFileExplorer() async {
    setState(() => _loadingPath = true);
    try {
      if (_multiPick) {
        _path = null;
        _paths = await FilePicker.getMultiFilePath(
            type: _pickingType,
            allowedExtensions: (_extension?.isNotEmpty ?? false)
                ? _extension?.replaceAll(' ', '')?.split(',')
                : null);
      } else {
        _path = null;
        _paths = null;

        await FilePicker.getFilePath(
            type: _pickingType,
            allowedExtensions: (_extension?.isNotEmpty ?? false)
                ? _extension?.replaceAll(' ', '')?.split(',')
                : null);
        file = await FilePicker.getFile();
      }
    } on PlatformException catch (e) {
      print("Unsupported operation" + e.toString());
    }
    if (!mounted) return;
    setState(
      () {
        loading = true;
        _loadingPath = false;
        if (_path.split('/').last.split('.').last != "json" &&
            _path.split('/').last.split('.').last != "JSON") {
          _fileName = "Invalid Format. JSON File is required";
        } else {
          _fileName = _path != null
              ? _path.split('/').last
              : _paths != null ? _paths.keys.toString() : '...';
          file_scan(_path);
        }
        print("<><><><><><><><><><><><><><><><><" +
            _path.split('/').last.split('.').last);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        title: const Text('Route map Analysis'),
      ),
      body: new Center(
        child: Stack(
          children: <Widget>[
//        Column(
//          mainAxisAlignment: MainAxisAlignment.center,
//          children: <Widget>[
//            Expanded(
//                child: Image.asset(
//              'assets/home_bg.png',
//              fit: BoxFit.cover,
//              width: double.infinity,
//            )),
//          ],
//        ),
            new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new Padding(
                    padding: const EdgeInsets.only(top: 20.0), child: Text("")),
                new Padding(
                  padding: const EdgeInsets.only(top: 50.0, bottom: 20.0),
                  child: RaisedGradientButton(
                    child: Text(
                      'Select a JSON file',
                      style: TextStyle(color: Colors.white),
                    ),
                    gradient: LinearGradient(
                      colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
                    ),
                    width: MediaQuery.of(context).size.width / 1.2,
                    height: 60,
                    borderRadius: 10,
                    onPressed: () => _openFileExplorer(),
                  ),
                ),
                new Builder(
                  builder: (BuildContext context) => _loadingPath
                      ? Padding(
                          padding: const EdgeInsets.only(bottom: 10.0),
                          child: const CircularProgressIndicator())
                      : _path != null || _paths != null
                          ? new Container(
                              padding: const EdgeInsets.only(bottom: 30.0),
                              height: MediaQuery.of(context).size.height * 0.50,
                              child: new Scrollbar(
                                child: new ListView.separated(
                                  itemCount: _paths != null && _paths.isNotEmpty
                                      ? _paths.length
                                      : 1,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    final bool isMultiPath =
                                        _paths != null && _paths.isNotEmpty;
                                    final String name = 'File selected is  ' +
                                        (isMultiPath
                                            ? _paths.keys.toList()[index]
                                            : _fileName ?? '...');
                                    final path = isMultiPath
                                        ? _paths.values
                                            .toList()[index]
                                            .toString()
                                        : _path;

                                    return new ListTile(
                                      title: new Text(
                                        name,
                                      ),
                                      subtitle: new Text(path),
                                    );
                                  },
                                  separatorBuilder:
                                      (BuildContext context, int index) =>
                                          new Divider(),
                                ),
                              ),
                            )
                          : new Container(),
                ),
                loading == true
                    ? Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: CircularProgressIndicator(),
                      )
                    : Container(
                        child: Column(
                          children: <Widget>[
                            Text(
                              contentss,
                              style:
                                  TextStyle(color: Colors.red, fontSize: 19.0),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 12.0),
                            ),
                            RaisedGradientButton(
                              child: Text(
                                'Go Home',
                                style: TextStyle(color: Colors.white),
                              ),
                              gradient: LinearGradient(
                                colors: <Color>[
                                  Color(0xff13007D),
                                  Color(0xff02A0C7)
                                ],
                              ),
                              width: MediaQuery.of(context).size.width / 1.2,
                              height: 60,
                              borderRadius: 10,
                              onPressed: () =>
                                  Navigator.pushNamedAndRemoveUntil(
                                context,
                                '/homepage',
                                ModalRoute.withName('/homepage'),
                              ),
                            ),
                          ],
                        ),
                      )
              ],
            ),
          ],
        ),
      ),
    );
  }

  void file_scan(String path) {
    file.readAsString().then((String contents) {
      var decoded = jsonDecode(contents);
      for (int i = 0; i < decoded["timelineObjects"].length; i++) {
        if (decoded["timelineObjects"][i]["placeVisit"] != null) {
          for (int j = 0;
              j <
                  decoded["timelineObjects"][i]["placeVisit"]
                          ["otherCandidateLocations"]
                      .length;
              j++) {
            checkThis(
                new LatLng(
                    (decoded["timelineObjects"][i]["placeVisit"]
                            ["otherCandidateLocations"][j]["latitudeE7"] *
                        0.0000001),
                    (decoded["timelineObjects"][i]["placeVisit"]
                            ["otherCandidateLocations"][j]["longitudeE7"] *
                        0.0000001)),
                (decoded["timelineObjects"][i]["placeVisit"]
                    ["otherCandidateLocations"][j]["placeId"]),
                decoded["timelineObjects"][i]["placeVisit"]["duration"]
                    ["startTimestampMs"],
                decoded["timelineObjects"][i]["placeVisit"]["duration"]
                    ["endTimestampMs"]);
          }
        }
      }
      setState(() {
        loading = false;
        contentss = count.toString() + " VULNERABILITIES FOUND";
      });
    }).catchError((e) {
      print(e);
    });
  }

  void checkThis(LatLng latLng, var place, var string, var string2) {
    DateTime d1 = DateTime.fromMillisecondsSinceEpoch(int.parse(string));
    DateTime d2 = DateTime.fromMillisecondsSinceEpoch(int.parse(string2));

    int diffDays = d2.difference(d1).inMinutes;
    // print("========="+d1.toString()+","+d2.toString()+","+diffDays.toString()+","+ d1.difference(d2).inMilliseconds.toString());
    final currentTime = DateTime.now();

    if (currentTime.isAfter(d1) && currentTime.isBefore(d2)) {
      // do something
      print("INSIDE");
    }

    for (int p = 0; p < list.length; p++) {
      DateTime toCheck1 =
          DateTime.fromMillisecondsSinceEpoch(int.parse(list[p].startt));
      DateTime toCheck2 =
          DateTime.fromMillisecondsSinceEpoch(int.parse(list[p].endt));
      // print("IN------d1="+d1.toString()+", d2="+d2.toString()+", c1="+toCheck1.toString()+", c2="+toCheck2.toString()+"--------"+d1.isAfter(toCheck1).toString()+d1.isBefore(toCheck2).toString() + d2.isAfter(toCheck1).toString()+d2.isBefore(toCheck2).toString() + toCheck1.isAfter(d1).toString()+toCheck1.isBefore(d2).toString()+ toCheck2.isAfter(d1).toString()+toCheck2.isBefore(d2).toString());
      //  print("()()()()()()()()()()()()()"+d1.difference(toCheck1).inMinutes.toString()+","+d1.difference(toCheck2).inMinutes.toString());
      if (d1.isAfter(toCheck1) && d1.isBefore(toCheck2) ||
          d1.difference(toCheck1).inMinutes < 10 ||
          d1.difference(toCheck2).inMinutes < 10 ||
          d2.difference(toCheck1).inMinutes < 10 ||
          d2.difference(toCheck2).inMinutes < 10 ||
          d2.isAfter(toCheck1) && d2.isBefore(toCheck2) ||
          toCheck1.isAfter(d1) && toCheck1.isBefore(d2) ||
          toCheck2.isAfter(d1) && toCheck2.isBefore(d2)) {
        print("INSIDE------l1=" +
            latLng.latitude.toString() +
            ", l2=" +
            latLng.longitude.toString() +
            ", ll1=" +
            list[p].lat.toString() +
            ", ll2=" +
            list[p].lng.toString());
        final Distance distance = new Distance();

        final double meter = distance.as(LengthUnit.Kilometer, latLng,
            new LatLng(double.parse(list[p].lat), double.parse(list[p].lng)));
        if (meter < 5) {
          count++;
          insert2db(string, string2, place, list[p].uid, latLng.latitude,
              latLng.longitude);
        }
      }
    }
  }

  Future<void> insert2db(String d1, String d2, String place, String uidd,
      double latitude, double longitude) async {
    print("0-0-0-0-0-0-0-0-0-0-0-0-0-" + phone.toString());
    var data = {
      "aadhar": uid,
      "name": name,
      "phone": phone,
      "gender": gender,
      "yob": yob,
      "gname": gname,
      "house": house,
      "lm": lm,
      "vtc": vtc,
      "po": po,
      "dist": dist,
      "state": state,
      "pc": pc,
      "d1": d1,
      "d2": d2,
      "lat": latitude.toString(),
      "lng": longitude.toString(),
      "place": place.toString(),
      "uid": uidd.toString()
    };
    var url = "http://arkroot.com/covid/saveCase.php";

    http.Response response = await http
        .post(url,
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: data,
            encoding: Encoding.getByName("utf-8"))
        .then((var response) {});
  }
}

Future<String> request_offers() async {
  var data = {};
  var url = "http://arkroot.com/covid/refresh.php";
  print("UID------------------------" + uid);
  http.Response response = await http
      .post(url,
          headers: {"Content-Type": "application/x-www-form-urlencoded"},
          body: {"uid": uid},
          encoding: Encoding.getByName("utf-8"))
      .then((var response) {
    List res = response.body.split("\n");
    if (res[0].toString().compareTo("<!DOCTYPE html>") == 1) {
      var dat;
      print(response.body);
      dat = jsonDecode(response.body);
      for (int i = 0; i < dat.length; i++) {
        list.add(new Patient(dat[i]["uid"], dat[i]["lat"], dat[i]["lng"],
            dat[i]["name"], dat[i]["startt"], dat[i]["endt"]));
      }
    }
  });
  return response.toString();
}
