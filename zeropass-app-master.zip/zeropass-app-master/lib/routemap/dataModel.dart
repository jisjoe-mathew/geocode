class Patient{
String uid,lat,lng,name,startt,endt;

Patient(this.uid, this.lat, this.lng, this.name, this.startt, this.endt);



}