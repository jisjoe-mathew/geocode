import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:share/share.dart';
import 'package:zeropass/helpers/database_helper.dart';

class TravelHistoryPage extends StatefulWidget {
  @override
  _TravelHistoryPageState createState() => _TravelHistoryPageState();
}

class _TravelHistoryPageState extends State<TravelHistoryPage> {
  final dbHelper = DatabaseHelper.instance;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  List<Map> routes = [];

  void _query() async {
    final allRows = await dbHelper.queryAllRows();
    routes = [];
    allRows.forEach((row) {
      print(row.runtimeType);
      Map<String, dynamic> data = {
        'id': row['_id'],
        'time': DateFormat('dd-MM-yyyy')
            .add_jm()
            .format(DateTime.parse(row['time'])),
        'lat': row['lat'],
        'long': row['long'],
      };
      routes.add(data);
//      routes = routes.reversed.toList();
    });
    setState(() {});
  }

  void _deleterow(int id) async {
//    final id = await dbHelper.queryRowCount();
    final rowsDeleted = await dbHelper.delete(id);
    print('deleted $rowsDeleted row(s): row $id');
    _query();
  }

  @override
  void initState() {
    _query();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Travel History',
          style: TextStyle(
            fontSize: 24,
            fontFamily: "RussoOne",
            color: Colors.black.withOpacity(0.8),
            letterSpacing: 1.3,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              Icons.share,
            ),
            onPressed: () {
              Share.share(routes.toString());
            },
          ),
          SizedBox(
            width: 10.0,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text('Your travel history is stored from 9 AM to 9 PM'),
            SizedBox(
              height: 10.0,
            ),
            ListView.builder(
                shrinkWrap: true,
                primary: false,
                itemCount: routes.length,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: 10.0, vertical: 2.0),
                    decoration: BoxDecoration(
                      color: Colors.teal.shade100,
                      borderRadius: BorderRadius.circular(16.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          offset: Offset(2.0, 2.0),
                          blurRadius: 4.0,
                        ),
                      ],
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 10.0),
                      focusColor: Colors.teal,
                      leading: ClipOval(
                          child: Image.asset('assets/images/location/pin.jpg')),
                      trailing: IconButton(
                        icon: Icon(
                          Icons.delete,
                          color: Colors.black.withOpacity(0.8),
                        ),
                        onPressed: () {
                          _deleterow(routes[(routes.length) - index - 1]['id']);
                        },
                      ),
                      title: Text(routes[(routes.length) - index - 1]['time']),
                      subtitle: Text(
                          '${routes[(routes.length) - index - 1]['lat']}, ${routes[(routes.length) - index - 1]['long']}'),
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext dialogContext) {
                            return showMap(
                                routes[(routes.length) - index - 1]['lat'],
                                routes[(routes.length) - index - 1]['long']);
                          },
                        );
                      },
                    ),
                  );
                }),
          ],
        ),
      ),
    );
  }

  showMap(double lat, double long) {
    Completer<GoogleMapController> _googleMapController = Completer();
    List<Marker> markers = [];
    LatLng latlng = LatLng(lat, long);
    markers.add(
      Marker(
        markerId: MarkerId(LatLng(lat, long).toString()),
        position: LatLng(lat, long),
        draggable: false,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      ),
    );
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
      content: Container(
        height: MediaQuery.of(context).size.height / 2.5,
        child: GoogleMap(
          initialCameraPosition: CameraPosition(target: latlng, zoom: 14.0),
          markers: Set.from(markers),
          mapType: MapType.normal,
          onMapCreated: (GoogleMapController googleMapController) {
            _googleMapController.complete(googleMapController);
          },
        ),
      ),
      actions: <Widget>[
        MaterialButton(
          color: Colors.red.shade100,
          child: Text(
            'Close',
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  showSnackBar(Color color, String text) {
    return _scaffoldKey.currentState.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: ContinuousRectangleBorder(
            borderRadius: BorderRadius.circular(30.0)),
        content: Text(
          text,
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }
}
