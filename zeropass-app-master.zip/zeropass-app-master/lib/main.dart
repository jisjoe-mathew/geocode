import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import 'package:zeropass/auth/ph_auth_service.dart';
import 'package:zeropass/checkup/Chatd.dart';
import 'package:zeropass/checkup/Chate.dart';
import 'package:zeropass/checkup/Chatf.dart';
import 'package:zeropass/checkup/Chatg.dart';
import 'package:zeropass/checkup/Chath.dart';
import 'package:zeropass/routemap/filll.dart';
import 'package:zeropass/routemap/welcome.dart';

import 'checkup/Chata.dart';
import 'checkup/Chatb.dart';
import 'checkup/Chatc.dart';
import 'helpers/database_helper.dart';
import 'home/homepage.dart';

final dbHelper = DatabaseHelper.instance;

void callbackDispatcher() {
  Workmanager.executeTask((task, inputData) async {
    await backgroundTask();
    return Future.value(true);
  });
}

backgroundTask() async {
  var timeChecker = int.parse(DateFormat('H').format(DateTime.now()));
  if (timeChecker >= 9 && timeChecker < 21) {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    Map<String, dynamic> row = {
      DatabaseHelper.columnTime: '${DateTime.now()}',
      DatabaseHelper.columnLat: position.latitude,
      DatabaseHelper.columnLong: position.longitude
    };
    await dbHelper.insert(row);
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Workmanager.initialize(callbackDispatcher, isInDebugMode: false);
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  work() async {
    await Workmanager.cancelAll();
    Workmanager.registerPeriodicTask(
      "1",
      "PeriodicTask",
//      frequency: Duration(minutes: 15),
    );
  }

  @override
  void initState() {
    work();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: <String, WidgetBuilder>{
        '/homepage': (BuildContext context) => MyHomePage(),
        '/routeapp': (BuildContext context) => WelcomePage(),
        '/filechoose': (BuildContext context) => FilePickerDemo(),
        '/chata': (BuildContext context) => Chata(),
        '/chatb': (BuildContext context) => Chatb(),
        '/chatc': (BuildContext context) => Chatc(),
        '/chatd': (BuildContext context) => Chatd(),
        '/chate': (BuildContext context) => Chate(),
        '/chatf': (BuildContext context) => Chatf(),
        '/chatg': (BuildContext context) => Chatg(),
        '/chath': (BuildContext context) => Chath(),
      },
      debugShowCheckedModeBanner: false,
      title: 'ZeroPass',
      theme: ThemeData(
        primaryColor: Theme.of(context).canvasColor,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthService().handleAuth(),
    );
  }
}
