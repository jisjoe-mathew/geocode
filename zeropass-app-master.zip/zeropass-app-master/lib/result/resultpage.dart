import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ResultPage extends StatefulWidget {
  Map data;

  ResultPage({this.data});

  @override
  _ResultPageState createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final dbRef = FirebaseDatabase.instance.reference();
  final FirebaseMessaging _messaging = FirebaseMessaging();

  bool isExpired = false, isLoading = true;
  String name, mob, myTaluk, myDistrict, myToken;
  bool quarantine = false, containment = false, myContainment = false;
  DateTime issueTime;
  double lat, long;

  checkTimeDelay() async {
    issueTime = DateTime.parse(widget.data['timestamp']);
    var difference = (DateTime.now()).difference(issueTime).inMinutes;
    if (difference < 10) {
      getDetails();
    } else {
      setState(() {
        isExpired = true;
      });
    }
  }

  getDetails() async {
    dbRef
        .child(
            'Regions/${widget.data['dst']}/${widget.data['tlk']}/Users/${widget.data['token']}')
        .onValue
        .listen((event) {
      name = event.snapshot.value['Name'];
      mob = event.snapshot.value['Mob'];
      containment = event.snapshot.value['Containment'];
      quarantine = event.snapshot.value['Quarantine'];
      _getMyData();
      setState(() {
        isLoading = false;
      });
    });
  }

  _getMyData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    myTaluk = prefs.getString('taluk');
    myDistrict = prefs.getString('district');
    var t = await _messaging.getToken();
    myToken = t.toString();
    getMyDetails();
  }

  getMyDetails() async {
    dbRef
        .child('Regions/$myDistrict/$myDistrict/Users/$myToken')
        .onValue
        .listen((event) {
      myContainment = event.snapshot.value['Containment'];
      findBreaks();
    });
  }

  findBreaks() async {
    if (quarantine) {
      addQuarantineBreak();
    } else if (containment) {
      if (myTaluk != widget.data['tlk']) {
        addContainmentBreak();
      } else if (!myContainment) {
        addContainmentBreak();
      } else if (myContainment) {
        showSnackBar(Colors.blue.shade700,
            'Both of you are in containment zone.\nKeep a distance and avoid interaction');
      }
    } else {
      showSnackBar(Colors.teal, 'This Person is Safe');
    }
  }

  addContainmentBreak() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    String date = DateTime.now().toString();
    String d = date;
    date = date.replaceAll(" ", "");
    date = date.replaceAll("-", "");
    date = date.replaceAll(":", "");
    date = date.replaceAll(".", "");
    double lat = position.latitude;
    double long = position.longitude;
    dbRef
        .child(
            'Regions/${widget.data['dst']}/${widget.data['tlk']}/Breaks/ContainmentBreak/${widget.data['token']}')
        .update({
          'Mob': mob,
          date: {'Lat': lat, 'Long': long, 'Time': d}
        })
        .then((value) => showSnackBar(Colors.red,
            'Containment break found\nIncident Reported\nKeep a safe distance from the person'))
        .catchError((e) => showSnackBar(Colors.red,
            'Containment break found\nUnable to report incident\nContact police and keep a safe distance from the person'));
  }

  addQuarantineBreak() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    String date = DateTime.now().toString();
    String d = date;
    date = date.replaceAll(" ", "");
    date = date.replaceAll("-", "");
    date = date.replaceAll(":", "");
    date = date.replaceAll(".", "");
    double lat = position.latitude;
    double long = position.longitude;
    print(date);
    dbRef
        .child(
            'Regions/${widget.data['dst']}/${widget.data['tlk']}/Breaks/QuarantineBreak/${widget.data['token']}')
        .update({
          'Mob': mob,
          date: {'Lat': lat, 'Long': long, 'Time': d}
        })
        .then((value) => showSnackBar(Colors.red,
            'Quarantine break found\nIncident Reported\nKeep a safe distance from the person'))
        .catchError((e) => showSnackBar(Colors.red,
            'Quarantine break found\nUnable to report incident\nContact police and keep a safe distance from the person'));
  }

  @override
  void initState() {
    checkTimeDelay();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'View Scan Result',
          style: TextStyle(
            fontSize: 24,
            fontFamily: "RussoOne",
            color: Colors.black.withOpacity(0.8),
            letterSpacing: 1.3,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(12.0),
        child: Column(
          children: [
            isExpired
                ? Container(
                    height: 300,
                    width: double.infinity,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "OOPS!",
                          style: TextStyle(
                            color: Colors.red.shade800,
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          "Pass Expired\nAsk to submit new Pass",
                          style: TextStyle(
//                          color: Colors.red.shade800,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  )
                : Column(
                    children: [
                      isLoading
                          ? Container(
                              height: 200,
                              child: Center(
                                child: CircularProgressIndicator(),
                              ),
                            )
                          : Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12.0, vertical: 20.0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16.0),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    offset: Offset(2.0, 2.0),
                                    blurRadius: 4.0,
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Zero Pass',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "RussoOne",
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 12.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text('Person Name: '),
                                      ),
                                      Flexible(
                                        flex: 2,
                                        child: name == null
                                            ? linearProgress()
                                            : Text(
                                                name,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text('Resident District: '),
                                      ),
                                      Flexible(
                                        flex: 2,
                                        child: widget.data['dst'] == null
                                            ? linearProgress()
                                            : Text(
                                                widget.data['dst'],
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text('Resident Block: '),
                                      ),
                                      Flexible(
                                        flex: 2,
                                        child: widget.data['tlk'] == null
                                            ? linearProgress()
                                            : Text(
                                                widget.data['tlk'],
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 2,
                                        child: Text(
                                          'Zone Status:',
                                        ),
                                      ),
                                      SizedBox(
                                        width: 8.0,
                                      ),
                                      Flexible(
                                        flex: 4,
                                        child: containment == null
                                            ? linearProgress()
                                            : Text(
                                                containment
                                                    ? 'Containment Zone'
                                                    : 'Not From Containment Zone',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: containment
                                                      ? Colors.red.shade800
                                                      : Colors.teal.shade800,
                                                ),
                                              ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text(
                                          'Quarantine Status:',
                                        ),
                                      ),
                                      SizedBox(
                                        width: 8.0,
                                      ),
                                      Flexible(
                                        flex: 1,
                                        child: quarantine == null
                                            ? linearProgress()
                                            : Text(
                                                quarantine
                                                    ? 'In Quarantine'
                                                    : 'Not In Quarantine',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: quarantine
                                                      ? Colors.red.shade800
                                                      : Colors.teal.shade800,
                                                ),
                                              ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.0,
                                  ),
                                  Row(
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text('Pass Issued: '),
                                      ),
                                      Flexible(
                                        flex: 3,
                                        child: Text(
                                          DateFormat.yMEd()
                                              .add_jm()
                                              .format(issueTime),
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
//                                      color: Colors.teal.shade800,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                      SizedBox(
                        height: 30.0,
                      ),
                      Container(
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Follow This Instructions After Scanning QR',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              "- Please check Zone Status & Quarantine Status.",
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              "- Keep distance and inform nearby police station if the person is found to be in quarantine.",
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              "- If the person comes from containment zone where you are not located, inform nearby police station.",
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              "- If everything is fine, allow person to do his activity and avoid maximum interaction.",
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                          ],
                        ),
                      )
                    ],
                  )
          ],
        ),
      ),
    );
  }

  linearProgress() {
    return LinearProgressIndicator(
      backgroundColor: Colors.black.withOpacity(0.2),
      valueColor: AlwaysStoppedAnimation<Color>(
        Colors.teal.shade800,
      ),
//      value: 0.8,
    );
  }

  showSnackBar(Color color, String text) {
    return _scaffoldKey.currentState.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: ContinuousRectangleBorder(
            borderRadius: BorderRadius.circular(30.0)),
        content: Text(
          text,
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 10),
      ),
    );
  }
}
