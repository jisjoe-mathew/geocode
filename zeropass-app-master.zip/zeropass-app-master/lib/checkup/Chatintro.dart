import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/checkup/raised_gradient_button.dart';

class Chatintro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Chat Home Page');
  }
}

SharedPreferences localStorage;

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController age = new TextEditingController();
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();

  Future loadMusic() async {
    player = await cache.play("mp3/c1.mp3");
  }

  @override
  void initState() {
    super.initState();
    loadMusic();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
    }

    initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  "assets/images/general/chatbot.gif",
                ),
                Center(
                  child: Text(
                    "PLEASE RAISE  VOLUME LEVELS TO LISTEN",
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 18.0,
                      fontWeight: FontWeight.w800,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Padding(padding: EdgeInsets.only(top: 12)),
                Padding(padding: EdgeInsets.only(top: 12)),
                Padding(
                  padding: const EdgeInsets.only(top: 12.0),
                  child: RaisedGradientButton(
                    child: Text(
                      'Next',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    gradient: LinearGradient(
                      colors: <Color>[
                        Colors.blueAccent.shade200,
                        Colors.blueAccent.shade700,
                      ],
                    ),
                    width: MediaQuery.of(context).size.width / 1.2,
                    height: 60,
                    borderRadius: 30,
                    onPressed: _validate,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future _validate() async {
    if (age.text != "") {
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red);
    } else {
      await localStorage.setString("age", age.text.toString());
      player?.stop();
      Navigator.of(context).pushReplacementNamed('/chata');
    }
  }
}
