import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/checkup/raised_gradient_button.dart';

class Chata extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHome(title: 'Flutter Demo Home Page');
  }
}

SharedPreferences localStorage;

class MyHome extends StatefulWidget {
  MyHome({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomeState createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  TextEditingController age = new TextEditingController();
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();

  Future loadMusic() async {
    player = await cache.play("mp3/c2.mp3");
  }

  @override
  void initState() {
    super.initState();
    loadMusic();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
    }

    initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(30.0),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Center(
                    child: Text(
                      "RAISE  VOLUME LEVELS TO LISTEN",
                      style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 18.0,
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                  Padding(padding: EdgeInsets.only(top: 12)),
                  Text(
                    "Please enter your Age",
                    style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 18.0,
                        fontWeight: FontWeight.w800),
                  ),
                  Padding(padding: EdgeInsets.only(top: 12)),
                  TextField(
                    controller: age,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    decoration: new InputDecoration(
                        contentPadding: EdgeInsets.symmetric(horizontal: 20),
                        border: new OutlineInputBorder(
                          borderRadius: const BorderRadius.all(
                            const Radius.circular(40.0),
                          ),
                        ),
                        filled: true,
                        hintStyle: new TextStyle(color: Colors.grey),
                        hintText: "Age",
                        fillColor: Colors.white),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30.0),
                    child: RaisedGradientButton(
                      child: Text(
                        'Next',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      gradient: LinearGradient(
                        colors: <Color>[
                          Colors.blueAccent.shade200,
                          Colors.blueAccent.shade700,
                        ],
                      ),
                      width: MediaQuery.of(context).size.width / 1.2,
                      height: 60,
                      borderRadius: 40,
                      onPressed: _validate,
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future _validate() async {
    if (age.text == "") {
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red);
    } else {
      await localStorage.setString("age", age.text.toString());
      player?.stop();
      Navigator.of(context).pushReplacementNamed('/chatb');
    }
  }
}
