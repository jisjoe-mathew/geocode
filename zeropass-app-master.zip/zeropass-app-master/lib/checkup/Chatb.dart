import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/checkup/raised_gradient_button.dart';

class Chatb extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHome(title: 'Flutter Demo Home Page');
  }
}

SharedPreferences localStorage;
enum PatientGender { Normal, Fever, High }

PatientGender _patientGender = PatientGender.Normal;
String fever = "Normal";

class MyHome extends StatefulWidget {
  MyHome({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomeState createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  TextEditingController age = new TextEditingController();
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();

  Future loadMusic() async {
    player = await cache.play("mp3/c3.mp3");
  }

  @override
  void initState() {
    super.initState();
    loadMusic();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
    }

    initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Please select your body Temperature",
                  style: TextStyle(
                      color: Colors.grey[700],
                      fontSize: 18.0,
                      fontWeight: FontWeight.w800),
                ),
                Padding(padding: EdgeInsets.only(top: 12)),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(padding: EdgeInsets.only(top: 8)),
                      Padding(padding: EdgeInsets.only(top: 8)),
                      Wrap(
                        direction: Axis.horizontal,
                        children: <Widget>[
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Radio(
                                value: PatientGender.Normal,
                                groupValue: _patientGender,
                                onChanged: (PatientGender value) {
                                  setState(() {
                                    _patientGender = value;
                                    fever = "Normal";
                                  });
                                },
                              ),
                              Text(
                                'Normal',
                                style: new TextStyle(fontSize: 16.0),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Radio(
                                value: PatientGender.Fever,
                                groupValue: _patientGender,
                                onChanged: (PatientGender value) {
                                  setState(() {
                                    _patientGender = value;
                                    fever = "Fever (98-102 F)";
                                  });
                                },
                              ),
                              Text(
                                'Fever',
                                style: new TextStyle(
                                  fontSize: 16.0,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Radio(
                                value: PatientGender.High,
                                groupValue: _patientGender,
                                onChanged: (PatientGender value) {
                                  setState(() {
                                    _patientGender = value;
                                    fever = "High Fever";
                                  });
                                },
                              ),
                              Text(
                                'High Fever >102 F',
                                style: new TextStyle(fontSize: 16.0),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 70,
                      ),
                      RaisedGradientButton(
                        child: Text(
                          'Next',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        gradient: LinearGradient(
                          colors: <Color>[
                            Colors.blueAccent.shade200,
                            Colors.blueAccent.shade700,
                          ],
                        ),
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 60,
                        borderRadius: 30,
                        onPressed: _validate,
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future _validate() async {
    if (fever == "") {
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red);
    } else {
      localStorage.setString("fever", fever.toString());
      player?.stop();
      Navigator.of(context).pushReplacementNamed('/chatc');
    }
  }
}
