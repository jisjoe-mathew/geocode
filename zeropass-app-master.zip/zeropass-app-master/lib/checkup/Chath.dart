import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:zeropass/checkup/raised_gradient_button.dart';

class Chath extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHome(title: 'Flutter Demo Home Page');
  }
}

SharedPreferences localStorage;
var fever = "",
    age = "",
    tmmpa = "",
    tmmpb = "",
    tmmpc = "",
    tmmpd = "",
    tmmpe = "",
    result = "",
    score = 0;
String uid,
    name,
    phone,
    gender,
    yob,
    gname,
    house,
    lm,
    vtc,
    po,
    dist,
    state,
    pc;

class MyHome extends StatefulWidget {
  MyHome({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomeState createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final dbRef = FirebaseDatabase.instance.reference();
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();

  Future loadMusic() async {
    player = await cache.play("mp3/high.mp3");
  }

  Future loadMusicm() async {
    player = await cache.play("mp3/medium.mp3");
  }

  Future loadMusicl() async {
    player = await cache.play("mp3/low.mp3");
  }

  save(String text) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String date = DateFormat('dd-MM-yyyy').add_jm().format(DateTime.now());
    await prefs.setString('healthText', '$text Risk');
    await prefs.setString('healthTime', date);
  }

  setInDB() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String district = prefs.getString('district');
    String taluk = prefs.getString('taluk');
    var t = await _messaging.getToken();
    String token = t.toString();
    dbRef
        .child('Regions/$district/$taluk/Users/$token')
        .update({'Status': '$result Risk'}).catchError((e) {});
  }

  @override
  void initState() {
    super.initState();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
      age = localStorage.getString("age");
      fever = localStorage.getString("fever");
      tmmpa = localStorage.getString("tmmpa");
      tmmpb = localStorage.getString("tmmpb");
      tmmpc = localStorage.getString("tmmpc");
      tmmpd = localStorage.getString("tmmpd");
      tmmpe = localStorage.getString("tmmpe");
      uid = localStorage.getString("uid") != null
          ? localStorage.getString("uid")
          : "";
      name = localStorage.getString("name") != null
          ? localStorage.getString("name")
          : "";
      phone = localStorage.getString("phone") != null
          ? localStorage.getString("phone")
          : "";
      gender = localStorage.getString("gender") != null
          ? localStorage.getString("gender")
          : "";
      yob = localStorage.getString("yob") != null
          ? localStorage.getString("yob")
          : "";
      gname = localStorage.getString("gname") != null
          ? localStorage.getString("gname")
          : "";
      house = localStorage.getString("house") != null
          ? localStorage.getString("house")
          : "";
      lm = localStorage.getString("lm") != null
          ? localStorage.getString("lm")
          : "";
      vtc = localStorage.getString("vtc") != null
          ? localStorage.getString("vtc")
          : "";
      po = localStorage.getString("po") != null
          ? localStorage.getString("po")
          : "";
      dist = localStorage.getString("dist") != null
          ? localStorage.getString("dist")
          : "";
      state = localStorage.getString("state") != null
          ? localStorage.getString("state")
          : "";
      pc = localStorage.getString("pc") != null
          ? localStorage.getString("pc")
          : "";
      print("........>>>>>>>>>>>>>>>>>>" +
          age +
          "," +
          fever +
          "," +
          tmmpa +
          "," +
          tmmpb +
          "," +
          tmmpc +
          "," +
          tmmpd +
          "," +
          tmmpe);
      await insert2db();
    }

    initShared();
  }

  Future<void> insert2db() async {
    print("ENCODED-------" + json.encode(tmmpa));

    var data = {
      "aadhar": uid,
      "name": name,
      "phone": phone,
      "gender": gender,
      "yob": yob,
      "gname": gname,
      "house": house,
      "lm": lm,
      "vtc": vtc,
      "po": po,
      "dist": dist,
      "state": state,
      "pc": pc,
      "age": age,
      "fever": fever,
      "tmmpa": json.encode(tmmpa),
      "tmmpb": json.encode(tmmpb),
      "tmmpc": json.encode(tmmpc),
      "tmmpd": json.encode(tmmpd),
      "tmmpe": json.encode(tmmpe)
    };
    print("DATA========" + data.toString());
    var url = "http://arkroot.com/covid/disease.php";

    await http
        .post(url,
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: data,
            encoding: Encoding.getByName("utf-8"))
        .then((var response) {
      print("JIS---===-=-=-=-===-=-=-=-=-=-" + response.body.toString());
      var dat = jsonDecode(response.body);
      for (int i = 0; i < dat.length; i++) {
        result = dat[i]["result"];
        score = dat[i]["score"];
        if (result == "High") {
          loadMusic();
        } else if (result == "Medium") {
          loadMusicm();
        } else if (result == "Low") {
          loadMusicl();
        }
        save(result);
        setInDB();
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "RESULTS",
              style: TextStyle(
                fontFamily: "Rowdies",
                color: Colors.blue,
                fontSize: 30.0,
                fontWeight: FontWeight.w900,
              ),
            ),
            Padding(padding: EdgeInsets.only(top: 20)),
            Center(
              child: Column(
                children: <Widget>[
                  (result == "High")
                      ? (Text(
                          "STATUS : " + result,
                          style: TextStyle(
                            fontSize: 25.0,
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ))
                      : ((result == "Medium")
                          ? (Text(
                              "STATUS : " + result,
                              style: TextStyle(
                                fontSize: 25.0,
                                color: Colors.orange,
                                fontWeight: FontWeight.bold,
                              ),
                            ))
                          : (Text(
                              "STATUS : " + result,
                              style: TextStyle(
                                fontSize: 25.0,
                                color: Colors.teal,
                                fontWeight: FontWeight.bold,
                              ),
                            ))),
                  Padding(
                    padding: EdgeInsets.only(top: 10.0),
                  ),
                  Text(
                    "Score from ML : " +
                        ((score / 35) * 100 * 10)
                            .toStringAsExponential(3)
                            .toString() +
                        " %",
                    style: TextStyle(
                      fontSize: 25.0,
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 150.0),
                    child: RaisedGradientButton(
                      child: Text(
                        'Finish',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      gradient: LinearGradient(
                        colors: <Color>[
                          Colors.blueAccent.shade200,
                          Colors.blueAccent.shade700,
                        ],
                      ),
                      width: MediaQuery.of(context).size.width / 1.2,
                      height: 60,
                      borderRadius: 30,
                      onPressed: () {
                        player?.stop();
                        Navigator.pop(context);
                      },
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
