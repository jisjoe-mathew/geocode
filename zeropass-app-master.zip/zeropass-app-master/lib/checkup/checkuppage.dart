import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CheckUpPage extends StatefulWidget {
  @override
  _CheckUpPageState createState() => _CheckUpPageState();
}

class _CheckUpPageState extends State<CheckUpPage> {
  bool iconVisible = true,
      freeIcon = false,
      startQuiz = false,
      finishQuiz = false;
  int index = 0, problemRank = 0;
  Random r = Random();
  List<String> questions = [
    '1. Do you have fever ?',
    '2. Do you have cough ?',
    '3. Do you have breathing problem ?',
    '4. Do you have sore throat ?',
    '5. Do you have headache ?'
  ];
  List<String> images = ['fever', 'cough', 'breath', 'sore', 'headache'];
  List<String> status = [
    'You are healthy',
    'Take rest you have chances for health problems',
    'Take rest and contact a doctor if necessary',
    'Take rest and contact a doctor soon',
    'You seem to be week immediately contact the doctor',
    'You seem to be week immediately contact the doctor',
  ];

  handleIcon() async {
    setState(() {
      iconVisible = false;
    });
    await Future.delayed(Duration(seconds: 1));
    setState(() {
      freeIcon = true;
      startQuiz = true;
    });
  }

  save() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String date = DateFormat('dd-MM-yyyy').add_jm().format(DateTime.now());
    await prefs.setString('healthText', status[problemRank]);
    await prefs.setString('healthTime', date);
    Navigator.pop(context);
  }

  next() async {
    if (index < (questions.length - 1)) {
      setState(() {
        startQuiz = false;
        index++;
      });
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        startQuiz = true;
      });
    } else {
      setState(() {
        startQuiz = false;
        finishQuiz = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            if (finishQuiz) {
              save();
            } else {
              Navigator.pop(context);
            }
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Visibility(
              visible: !freeIcon,
              child: AnimatedOpacity(
                opacity: iconVisible ? 1.0 : 0.0,
                duration: Duration(seconds: 1),
                child: icon(),
              ),
            ),
            SizedBox(
              height: 12.0,
            ),
            Center(
              child: Text(
                !freeIcon
                    ? 'Take A Quick Health Checkup'
                    : 'Daily Health Checkup',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                  fontFamily: 'Rowdies',
                  color: Colors.blueAccent.shade700,
                  letterSpacing: 1,
                ),
              ),
            ),
            Visibility(
              visible: !freeIcon,
              child: AnimatedOpacity(
                opacity: iconVisible ? 1.0 : 0.0,
                duration: Duration(seconds: 1),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 50.0,
                      ),
                      Text(
                        'Why Health Checkup ?',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black.withOpacity(0.8),
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Text(
                          'Regular health exams and tests can help find problems before they start. They also can help find problems early, when your chances for treatment and cure are better.',
                          style: TextStyle(fontStyle: FontStyle.italic),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 50.0,
            ),
            AnimatedOpacity(
              opacity: startQuiz ? 1.0 : 0.0,
              duration: Duration(seconds: 2),
              child: Visibility(
                visible: startQuiz,
                child: Column(
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height / 2,
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ClipOval(
                            child: Image.asset(
                              'assets/images/health/${images[index]}.jpg',
                              fit: BoxFit.fill,
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            questions[index],
                            style: TextStyle(
                              fontSize: 30,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Flexible(
                            flex: 1,
                            child: MaterialButton(
                              color: Colors.redAccent,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0)),
                              child: Text(
                                'No',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              onPressed: () {
                                next();
                              },
                            ),
                          ),
                          Flexible(
                            flex: 1,
                            child: MaterialButton(
                              color: Colors.teal,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0)),
                              child: Text(
                                'Yes',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              onPressed: () {
                                problemRank++;
                                next();
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            AnimatedOpacity(
              opacity: finishQuiz ? 1.0 : 0.0,
              duration: Duration(seconds: 1),
              child: Visibility(
                visible: finishQuiz,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    icon(),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        status[problemRank],
                        style: TextStyle(
//                          fontWeight: FontWeight.bold,
                          fontSize: 20.0,
                          fontFamily: 'Rowdies',
                          color: Colors.teal.shade700,
                          letterSpacing: 1,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        problemRank == 0
                            ? '0.00% chance found'
                            : '${((problemRank * 20) + (r.nextInt(20)) - 20).toString()}.${(r.nextInt(100)).toString()}% chance found',
                        style: TextStyle(
//                          fontWeight: FontWeight.bold,
                          fontSize: 20.0,
                          fontFamily: 'Rowdies',
                          color: Colors.red.shade700,
                          letterSpacing: 1,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
      floatingActionButton: Stack(
        children: [
          Visibility(
            visible: iconVisible,
            child: FloatingActionButton.extended(
              heroTag: null,
              backgroundColor: Colors.blueAccent.shade700,
              label: Text('Take Checkup Now'),
              onPressed: () {
                handleIcon();
              },
            ),
          ),
          Visibility(
            visible: finishQuiz,
            child: FloatingActionButton.extended(
              heroTag: null,
              backgroundColor: Colors.blueAccent.shade700,
              label: Text('Finish Quiz'),
              onPressed: () {
                save();
              },
            ),
          )
        ],
      ),
    );
  }

  icon() {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          margin: EdgeInsets.all(12.0),
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(42.0),
            boxShadow: [
              BoxShadow(
                color: Colors.blueAccent.shade200,
                offset: Offset(0, 6),
                blurRadius: 8.0,
              ),
            ],
          ),
          child: Hero(
            tag: 'checkup',
            child: ClipRRect(
              borderRadius: BorderRadius.circular(42.0),
              child: Image.asset(
                "assets/images/general/checkup.jpg",
                fit: BoxFit.fitHeight,
                colorBlendMode: BlendMode.colorBurn,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
