import 'dart:async';

import 'package:connectivity/connectivity.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/helpers/adddetails.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'ph_auth_service.dart';
import 'package:xml/xml.dart' as xml;

SharedPreferences localStorage;

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  StreamSubscription subscription;
  final dbRef = FirebaseDatabase.instance.reference();
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _mobFormKey = GlobalKey<FormState>();
  final _otpFormKey = GlobalKey<FormState>();

  String token,
      mob,
      verificationId,
      smsCode,
      aadharID,
      address,
      username,
      oldToken;
  bool codeSent = false, isAgree = false, isLoading = false, isRed = false;

  showOkDialog(String title, String content, Color color) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
      title: Text(
        title,
        style: TextStyle(color: color),
      ),
      content: Text(content),
      actions: <Widget>[
        MaterialButton(
          elevation: 5.0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
          color: color,
          child: Text(
            'OK',
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  void handleConnectivityChange(connectionState) {
    if (connectionState == ConnectivityResult.none) {
      _scaffoldKey.currentState.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          shape: ContinuousRectangleBorder(
              borderRadius: BorderRadius.circular(30.0)),
          content: Text(
            'No Internet Connection!',
            textAlign: TextAlign.center,
          ),
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  _checkConnectivity() {
    subscription = new Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) {
      handleConnectivityChange(result);
    });
  }

  _getDeviceToken() async {
    var t = await _messaging.getToken();
    token = t.toString();
  }

  @override
  void initState() {
    setS() async {
      SharedPreferences.setMockInitialValues({});
      localStorage = await SharedPreferences.getInstance();
    }

    setS();
    _checkConnectivity();
    _getDeviceToken();
    super.initState();
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          key: _scaffoldKey,
          body: SingleChildScrollView(
            child: Container(
//              height: MediaQuery.of(context).size.height * 0.8,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(height: 60.0),
                    Text(
                      'Zero-Pass',
                      style: TextStyle(
                        fontSize: 24,
                        fontFamily: "RussoOne",
                        color: Colors.black.withOpacity(0.8),
                        letterSpacing: 1.3,
                      ),
                    ),
                    Text(
                      'The Next Level Of Policing',
                      style: TextStyle(
                        wordSpacing: 1.5,
                        color: Colors.black.withOpacity(0.8),
                        letterSpacing: 1.3,
                      ),
                    ),
                    SizedBox(height: 80.0),
                    Visibility(
                      visible: !codeSent,
                      child: RaisedButton(
                        color: Colors.teal.shade100,
                        padding: EdgeInsets.all(20.0),
                        elevation: 6.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: Container(
                          width: MediaQuery.of(context).size.width / 2,
                          child: Text(
                            'SCAN AADHAR',
                            textAlign: TextAlign.center,
                          ),
                        ),
                        onPressed: () {
                          scanAadhar();
                        },
                      ),
                    ),
                    Form(
                      key: _mobFormKey,
                      child: Container(
                        margin: EdgeInsets.only(top: 16.0),
                        padding: EdgeInsets.only(
                            left: 16.0, right: 16.0, bottom: 4.0),
                        decoration: BoxDecoration(
                            color: Colors.blueGrey.shade100,
                            borderRadius: BorderRadius.circular(12.0)),
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            fontSize: 18.0,
                          ),
                          maxLength: 10,
                          decoration: InputDecoration(
                            labelText: "Phone Number",
                            labelStyle:
                                TextStyle(color: Colors.black.withOpacity(0.8)),
                            counterText: "",
                            border: InputBorder.none,
                            prefixText: "+91",
//                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          ),
                          validator: (value) {
                            String pattern = r'(^(?:[+0]9)?[0-9]{10,12}$)';
                            RegExp regExp = RegExp(pattern);
                            if (value.isEmpty ||
                                value.length != 10 ||
                                !regExp.hasMatch(value)) {
                              return 'Please enter correct mobile number!';
                            }
                            FocusScope.of(context).unfocus();
                            return null;
                          },
                          onChanged: (v) {
                            setState(() {
                              codeSent = false;
                              mob = v;
                            });
                          },
                        ),
                      ),
                    ),
                    Visibility(
                      visible: codeSent,
                      child: Form(
                        key: _otpFormKey,
                        child: Container(
                          margin: EdgeInsets.only(top: 16.0),
                          padding: EdgeInsets.only(
                              left: 16.0, right: 16.0, bottom: 4.0),
                          decoration: BoxDecoration(
                              color: Colors.blueGrey.shade100,
                              borderRadius: BorderRadius.circular(12.0)),
                          child: TextFormField(
                            keyboardType: TextInputType.number,
                            style: TextStyle(
                              fontSize: 18.0,
                            ),
                            decoration: InputDecoration(
                              labelText: "OTP",
                              labelStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.8)),
                              border: InputBorder.none,
//                          floatingLabelBehavior: FloatingLabelBehavior.always,
                            ),
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Please enter valid OTP!';
                              }
                              FocusScope.of(context).unfocus();
                              return null;
                            },
                            onChanged: (v) {
                              setState(() {
                                smsCode = v;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: !codeSent,
                      child: Container(
                        margin: EdgeInsets.only(top: 16.0),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Row(
                          children: [
                            Flexible(
                              flex: 1,
                              child: Checkbox(
                                value: isAgree,
                                onChanged: (v) {
                                  setState(() {
                                    isAgree = v;
                                  });
                                },
                              ),
                            ),
                            Flexible(
                              flex: 3,
                              child: Text(
                                "I Agree the ",
                                style: TextStyle(
                                  color: isRed
                                      ? Colors.red
                                      : Colors.blueGrey.shade900,
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 4,
                              child: SelectableText(
                                "Terms & Policy",
                                style: TextStyle(
                                  color: isRed ? Colors.red : Colors.blue,
                                ),
                                onTap: () {
//                                  Navigator.push(
//                                    context,
//                                    CupertinoPageRoute(
//                                      builder: (context) => PolicyPage(),
//                                    ),
//                                  );
                                },
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Visibility(
                      visible: !codeSent,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 24.0),
                        child: MaterialButton(
                          elevation: 10,
                          color: Colors.blueGrey.shade900,
//                            shape: RoundedRectangleBorder(
//                                borderRadius: BorderRadius.circular(16.0)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16.0,
                              vertical: 8.0,
                            ),
                            child: Text(
                              "Verify",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                          onPressed: () async {
                            if (!isAgree) {
                              setState(() {
                                isRed = true;
                              });
                              _scaffoldKey.currentState.showSnackBar(
                                SnackBar(
                                  behavior: SnackBarBehavior.floating,
                                  backgroundColor: Colors.redAccent,
                                  shape: ContinuousRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(30.0)),
                                  content: Text(
                                    'Please Agree the Terms & Condition to Verify',
                                    style: TextStyle(color: Colors.white),
                                    textAlign: TextAlign.center,
                                  ),
                                  duration: Duration(seconds: 3),
                                ),
                              );
                            } else if (aadharID == null || aadharID == '') {
                              _scaffoldKey.currentState.showSnackBar(
                                SnackBar(
                                  behavior: SnackBarBehavior.floating,
                                  backgroundColor: Colors.redAccent,
                                  shape: ContinuousRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(30.0)),
                                  content: Text(
                                    'Please Scan Your Aadhar Card',
                                    style: TextStyle(color: Colors.white),
                                    textAlign: TextAlign.center,
                                  ),
                                  duration: Duration(seconds: 3),
                                ),
                              );
                            } else if (_mobFormKey.currentState.validate()) {
                              setState(() {
                                isLoading = true;
                              });
                              await AddDetails().basicDetails(
                                  username, address, aadharID, mob);
                              checkPreviousDetail();
                            } else {
                              setState(() {
                                isRed = false;
                              });
                              return;
                            }
                          },
                        ),
                      ),
                    ),
                    Visibility(
                      visible: codeSent,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 24.0),
                        child: MaterialButton(
                          elevation: 10,
                          color: Colors.blue,
//                          shape: RoundedRectangleBorder(
//                              borderRadius: BorderRadius.circular(8.0)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16.0,
                              vertical: 8.0,
                            ),
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                          onPressed: () {
                            if (_otpFormKey.currentState.validate()) {
                              AuthService()
                                  .signInWithOTP(smsCode, verificationId);
                            } else {
                              return;
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        Visibility(
          visible: isLoading,
          child: WillPopScope(
            onWillPop: () async {
              if (isLoading) {
                return false;
              } else {
                return true;
              }
            },
            child: Scaffold(
              backgroundColor: Colors.black26,
              body: Center(
                child: CircularProgressIndicator(
//                backgroundColor: Colors.white,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future scanAadhar() async {
    try {
      var barcode = await BarcodeScanner.scan();
      var document = xml.parse(barcode.rawContent);
      var allStringElements =
          document.findAllElements('PrintLetterBarcodeData');

      var data = "";
      var details = new Map();

      // or do something useful with the whole list
      for (var element in allStringElements) {
        for (var elementa in element.attributes) {
          print(
              '${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}');
          data = data +
              '${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}' +
              '\n';
          details[elementa
              .toString()
              .substring(0, elementa.toString().indexOf('='))] = elementa.value;
        }
      }
      print(details);

      if (details != "") {
        localStorage.setString('uid', details["uid"].toString());
        localStorage.setString('name', details["name"].toString());
        localStorage.setString('gender', details["gender"].toString());
        localStorage.setString('yob', details["yob"].toString());
        localStorage.setString('gname', details["gname"].toString());
        localStorage.setString('house', details["house"].toString());
        localStorage.setString('lm', details["lm"].toString());
        localStorage.setString('vtc', details["vtc"].toString());
        localStorage.setString('po', details["po"].toString());
        localStorage.setString('dist', details["dist"].toString());
        localStorage.setString('state', details["state"].toString());
        localStorage.setString('pc', details["pc"].toString());
        localStorage.setBool('aadhar', true);
      }

      username = details['name'];
      address =
          '${details['house']}, ${details['lm']}, ${details['vtc']}, PO ${details['po']}, ${details['dist']}, Pin-Code: ${details['pc']}';
      aadharID = details['uid'];
      showSnackBar(Colors.teal, 'Aadhar Verified Successfully');
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        showSnackBar(
            Colors.red, 'The user did not grant the camera permission!');
      } else {
        showSnackBar(Colors.red, 'Unknown error: $e');
      }
    } on FormatException {
      showSnackBar(Colors.red, 'Failed Scanning!');
    } catch (e) {
      showSnackBar(Colors.red, 'Unknown error: $e');
    }
  }

  checkPreviousDetail() async {
    dbRef.child('PassID/$mob').once().then((snapshot) {
      if (snapshot.value != null) {
        print('found previous records');
        oldToken = snapshot.value['Token'];
        AddDetails().setPreviousDetails(snapshot.value['Tol'], true,
            snapshot.value['District'], snapshot.value['Taluk']);
        changeUserToken(snapshot.value['District'], snapshot.value['Taluk']);
      } else {
        print('no previous records');
        verifyUser(mob);
      }
    }).catchError((e) {
      setState(() {
        isLoading = false;
      });
      showSnackBar(Colors.red, 'Some Error Occured');
    });
  }

  changeUserToken(String dst, String tlk) async {
    dbRef.child('Regions/$dst/$tlk/Users/$oldToken').once().then((snapshot) {
      Map data = snapshot.value;
      dbRef.child('Regions/$dst/$tlk/Users/$token').update({
        'Status': data['Status'],
        'Tol': data['Tol'],
        'Breaks': data['Breaks'],
        'Mob': data['Mob'],
        'AadharID': data['AadharID'],
        'Address': data['Address'],
        'Long': data['Long'],
        'Quarantine': data['Quarantine'],
        'Lat': data['Lat'],
        'Containment': data['Containment'],
        'Name': data['Name'],
      }).then((value) {
        setNewToken(dst, tlk);
        if (oldToken != token) {
          dbRef
              .child('Regions/$dst/$tlk/Users/$oldToken')
              .remove()
              .catchError((e) {});
        }
      }).catchError((e) {
        showSnackBar(Colors.red, 'Some error occured. Try again!');
      });
    }).catchError((e) {
      showSnackBar(Colors.red, 'Some error occured. Try again!');
    });
  }

  setNewToken(String dst, String tlk) async {
    dbRef.child('Regions/$dst/$tlk/Tokens').update({
      mob: token,
    }).then((value) {
      dbRef.child('PassID/$mob').update({
        "Token": token,
      }).then((value) {
        verifyUser(mob);
      }).catchError((e) {
        showSnackBar(Colors.red, 'Some error occured. Try again!');
      });
    }).catchError((e) {
      showSnackBar(Colors.red, 'Some error occured. Try again!');
    });
  }

  Future verifyUser(String mobile) async {
    FirebaseAuth _auth = FirebaseAuth.instance;

    final PhoneVerificationCompleted verified = (AuthCredential authResult) {
      setState(() {
        isLoading = false;
      });
      AuthService().signIn(authResult);
    };

    final PhoneVerificationFailed verificationfailed =
        (AuthException authException) {
      setState(() {
        isLoading = false;
      });
      showDialog(
        context: context,
        builder: (BuildContext dialogContext) {
          return showOkDialog(
            'Verification Failed!',
            codeSent
                ? "Please enter correct OTP."
                : "Please check your connection.",
            Colors.red,
          );
        },
      );
    };

    final PhoneCodeSent smsSent = (String verId, [int forceResend]) {
      this.verificationId = verId;
      setState(() {
        isLoading = false;
        this.codeSent = true;
      });
    };

    final PhoneCodeAutoRetrievalTimeout autoTimeout = (String verId) {
      this.verificationId = verId;
    };

    _auth.verifyPhoneNumber(
      phoneNumber: '+91$mobile',
      timeout: const Duration(seconds: 60),
      verificationCompleted: verified,
      verificationFailed: verificationfailed,
      codeSent: smsSent,
      codeAutoRetrievalTimeout: autoTimeout,
    );
  }

  showSnackBar(Color color, String text) {
    setState(() {
      isLoading = false;
    });
    return _scaffoldKey.currentState.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: ContinuousRectangleBorder(
            borderRadius: BorderRadius.circular(30.0)),
        content: Text(
          text,
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }
}
