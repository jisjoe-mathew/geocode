import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class LogsPage extends StatefulWidget {
  @override
  _LogsPageState createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final dbRef = FirebaseDatabase.instance.reference();

  List area = [
    [76.081352, 11.61254],
    [76.078777, 11.611363],
    [76.078777, 11.60905],
    [76.080494, 11.608126],
    [76.082597, 11.607579],
    [76.084356, 11.609429],
    [6.084528, 11.612035],
    [76.082082, 11.612834],
    [76.081309, 11.612498],
  ];

  List<LatLng> _area = [
    LatLng(76.081352, 11.61254),
    LatLng(76.078777, 11.611363),
    LatLng(76.078777, 11.60905),
    LatLng(76.080494, 11.608126),
    LatLng(76.082597, 11.607579),
    LatLng(76.084356, 11.609429),
    LatLng(76.084528, 11.612035),
    LatLng(76.082082, 11.612834),
    LatLng(76.081309, 11.612498),
  ];

  _checkIfValidMarker(LatLng tap, List<LatLng> vertices) {
    int intersectCount = 0;
    for (int j = 0; j < vertices.length - 1; j++) {
      if (rayCastIntersect(tap, vertices[j], vertices[j + 1])) {
        intersectCount++;
      }
    }

    print(((intersectCount % 2) == 1));
//    return ((intersectCount % 2) == 1); // odd = inside, even = outside;
  }

  bool rayCastIntersect(LatLng tap, LatLng vertA, LatLng vertB) {
    double aY = vertA.latitude;
    double bY = vertB.latitude;
    double aX = vertA.longitude;
    double bX = vertB.longitude;
    double pY = tap.latitude;
    double pX = tap.longitude;

    if ((aY > pY && bY > pY) || (aY < pY && bY < pY) || (aX < pX && bX < pX)) {
      return false; // a and b can't both be above or below pt.y, and a or
      // b must be east of pt.x
    }

    double m = (aY - bY) / (aX - bX); // Rise over run
    double bee = (-aX) * m + aY; // y = mx + b
    double x = (pY - bee) / m; // algebra is neat!

    return x > pX;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          RaisedButton(
            child: Text('Check'),
            onPressed: () {
              _checkIfValidMarker(LatLng(76.078777, 11.60905), _area);
            },
          ),
          RaisedButton(
            child: Text('Add List'),
            onPressed: () {
              dbRef
                  .child('Regions/Thrissur/Thrissur/Polygon')
                  .update({'containmentZoneName': area});
            },
          ),
          RaisedButton(
            child: Text('Retrieve List'),
            onPressed: () {
              dbRef
                  .child('Regions/Thrissur/Thrissur/Polygon')
                  .once()
                  .then((snapshot) {
                Map data = snapshot.value;
                List zoneNames = [];
                List zones = [];
                data.forEach((key, value) {
                  zoneNames.add(key);
                  zones.add(value);
                });
                print(zoneNames);
                print(zones);
              });
            },
          )
        ],
      ),
    );
  }
}
