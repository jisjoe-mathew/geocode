import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:bubble_tab_indicator/bubble_tab_indicator.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:jitsi_meet/jitsi_meet.dart';
import 'package:jitsi_meet/jitsi_meeting_listener.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/about/aboutpage.dart';
import 'package:zeropass/auth/ph_auth_service.dart';
import 'package:zeropass/complaint/complaintpage.dart';
import 'package:zeropass/general/generalpage.dart';
import 'package:zeropass/policy/policypage.dart';
import 'package:zeropass/residence/residencepage.dart';
import 'package:zeropass/result/resultpage.dart';
import 'package:zeropass/routemap/welcome.dart';
import 'package:zeropass/updates/updatespage.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final FirebaseMessaging _messaging = FirebaseMessaging();

  List<Map> _notifications = [];
  String username;
  bool isLocationAdded = false, call = false;
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();
  String mob;

//  getDeviceToken() async {
//    var t = await _messaging.getToken();
//    token = t.toString();
//  }

  _getName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    username = prefs.getString('username');
    mob = prefs.getString('mob');
    isLocationAdded = prefs.getBool('isLocationAdded') ?? false;
    setState(() {});
  }

  _getNotification() {
    _messaging.configure(
      onMessage: (Map<String, dynamic> notification) async {
        _setNotification(notification);
      },
      onLaunch: (Map<String, dynamic> notification) async {
        _setNotification(notification);
      },
      onResume: (Map<String, dynamic> notification) async {
        _setNotification(notification);
      },
    );
  }

  _setNotification(Map<String, dynamic> notification) async {
    loadMusic();
    var notificationMap = notification['notification'];
    var dataMap = notification['data'];
    if (dataMap['message'] == "call" && !call) {
      setState(() {
        dataMap = {};
        call = true;
      });
    }
    print(_notifications);
  }

  Future loadMusic() async {
    player?.stop();
    player = await cache.play("mp3/call.mp3");
  }

  initJitsi() {
    JitsiMeet.addListener(JitsiMeetingListener(
        onConferenceWillJoin: _onConferenceWillJoin,
        onConferenceJoined: _onConferenceJoined,
        onConferenceTerminated: _onConferenceTerminated,
        onError: _onError));
  }

  @override
  void initState() {
    _getName();
    _getNotification();
//    getDeviceToken();
    initJitsi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FittedBox(
        child: FloatingActionButton(
          child: CircleAvatar(
            radius: 30,
            backgroundColor: Colors.black,
            child: CircleAvatar(
              radius: 25,
              child: ClipOval(
                child: Image.asset(
                  'assets/images/general/location.jpg',
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => WelcomePage()),
            );
          },
        ),
      ),
      key: _scaffoldKey,
      drawer: drawer(),
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        title: Text(
          'ZeroPass',
          style: TextStyle(
            fontSize: 24,
            fontFamily: "RussoOne",
            color: Colors.black.withOpacity(0.8),
            letterSpacing: 1.3,
          ),
        ),
        leading: IconButton(
          icon: Stack(
            children: [
              Icon(
                Icons.sort,
                color: Colors.black.withOpacity(0.2),
                size: 30,
              ),
              Positioned(
                bottom: 1.5,
                right: 2,
                child: Icon(
                  Icons.sort,
                  color: Colors.black.withOpacity(0.75),
                  size: 30,
                ),
              ),
            ],
          ),
          onPressed: () {
            _scaffoldKey.currentState.openDrawer();
            _getName();
          },
        ),
        actions: [
          IconButton(
            icon: Stack(
              children: [
                Icon(
                  Icons.fullscreen,
                  color: Colors.black.withOpacity(0.8),
                  size: 30,
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Icon(
                    Icons.apps,
                    color: Colors.black.withOpacity(0.8),
                    size: 10,
                  ),
                ),
              ],
            ),
            onPressed: () {
              if (isLocationAdded) {
                scan();
              } else {
                _getName();
                showSnackBar(
                    Colors.grey.shade700, 'Sorry !\nUnable to process');
              }
            },
          ),
          SizedBox(
            width: 10.0,
          ),
        ],
      ),
      body: DefaultTabController(
        length: 2,
        initialIndex: 1,
        child: NestedScrollView(
          headerSliverBuilder: (context, value) {
            return [
              SliverAppBar(
                leading: Container(),
                floating: true,
                pinned: false,
                snap: true,
                backgroundColor: Theme.of(context).canvasColor,
                flexibleSpace: TabBar(
                  indicator: new BubbleTabIndicator(
                    indicatorHeight: 30.0,
                    indicatorColor: Colors.black.withOpacity(0.8),
                    tabBarIndicatorSize: TabBarIndicatorSize.tab,
                  ),
                  labelColor: Theme.of(context).canvasColor,
                  unselectedLabelColor: Colors.black,
                  tabs: [
                    Tab(
                        child: Text(
                      'Latest Updates',
                      textAlign: TextAlign.center,
                    )),
                    Tab(
                        child: Text(
                      'General Info',
                      textAlign: TextAlign.center,
                    )),
//                    Tab(
//                        child: Text(
//                      'Daily Logs',
//                      textAlign: TextAlign.center,
//                    )),
                  ],
                ),
              ),
            ];
          },
          body: Stack(
            children: [
              TabBarView(
                children: [
                  UpdatesPage(),
                  GeneralPage(),
//              LogsPage(),
                ],
              ),
              Visibility(
                visible: call,
                child: Container(
                  margin: EdgeInsets.all(20.0),
//                  height: 100,
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.teal.withOpacity(0.6),
//                        offset: Offset(5.0, 5.0),
                        blurRadius: 10.0,
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: Text(
                          "Verification Call From ZeroPass",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Flexible(
                        flex: 2,
                        child: Wrap(
                          direction: Axis.horizontal,
                          spacing: 20,
                          children: [
                            FloatingActionButton(
                              backgroundColor: Colors.red,
                              heroTag: null,
                              mini: true,
                              child: Icon(
                                Icons.call_end,
                                color: Colors.white,
                              ),
                              onPressed: () {
                                setState(() {
                                  player?.stop();
                                  call = false;
                                });
                              },
                            ),
                            FloatingActionButton(
                              backgroundColor: Colors.teal,
                              heroTag: null,
                              mini: true,
                              child: Icon(
                                Icons.call,
                                color: Colors.white,
                              ),
                              onPressed: () {
                                if (mob != null && username != null) {
                                  setState(() {
                                    player?.stop();
                                    call = false;
                                  });
                                  _joinMeeting();
                                }
                              },
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  drawer() {
    return Drawer(
      child: SafeArea(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
//              color: Colors.blue,
                  ),
              child: username == null
                  ? Center(child: CircularProgressIndicator())
                  : Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 30,
                          child: Text(
                            username[0].toUpperCase(),
                            style: TextStyle(fontSize: 30.0),
                          ),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(username),
                      ],
                    ),
            ),
            Visibility(
              visible: isLocationAdded,
              child: Column(
                children: [
                  InkWell(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 8.0,
                          ),
                          Icon(
                            Icons.location_on,
                            color: Colors.red.shade800,
                          ),
                          SizedBox(
                            width: 16.0,
                          ),
                          Text('Edit Residence'),
                        ],
                      ),
                    ),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ResidencePage(),
                        ),
                      );
                      _getName();
                      Navigator.pop(context);
                    },
                  ),
                  Divider(),
                ],
              ),
            ),
            InkWell(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      width: 8.0,
                    ),
                    Icon(
                      Icons.border_color,
                      color: Colors.teal.shade900,
                    ),
                    SizedBox(
                      width: 16.0,
                    ),
                    Text('Register Complaint'),
                  ],
                ),
              ),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ComplaintPage(),
                  ),
                );
                Navigator.pop(context);
              },
            ),
            Divider(),
            InkWell(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      width: 8.0,
                    ),
                    Icon(
                      Icons.lock,
                      color: Colors.black.withOpacity(0.8),
                    ),
                    SizedBox(
                      width: 16.0,
                    ),
                    Text('Privacy Policy'),
                  ],
                ),
              ),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PolicyPage(),
                  ),
                );
                Navigator.pop(context);
              },
            ),
            Divider(),
            InkWell(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      width: 8.0,
                    ),
                    Icon(
                      Icons.info_outline,
                      color: Colors.orange.shade700,
                    ),
                    SizedBox(
                      width: 16.0,
                    ),
                    Text('About'),
                  ],
                ),
              ),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AboutPage(),
                  ),
                );
                Navigator.pop(context);
              },
            ),
            Divider(),
            InkWell(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      width: 8.0,
                    ),
                    Icon(
                      Icons.exit_to_app,
                      color: Colors.black.withOpacity(0.8),
                    ),
                    SizedBox(
                      width: 16.0,
                    ),
                    Text('Sign Out'),
                  ],
                ),
              ),
              onTap: () {
                AuthService().signOut();
              },
            ),
            Divider(),
          ],
        ),
      ),
    );
  }

  scan() async {
    try {
      var barcode = await BarcodeScanner.scan();
      var data = json.decode(barcode.rawContent);
      if (data['token'] != null && data['token'] != '') {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ResultPage(
              data: data,
            ),
          ),
        );
      } else {
        showSnackBar(Colors.red, 'Invalid Pass!');
      }
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        showSnackBar(
            Colors.red, 'The user did not grant the camera permission!');
      } else {
        showSnackBar(Colors.red, 'Unknown error: $e');
      }
    } on FormatException {
      showSnackBar(Colors.red, 'Failed Scanning!');
    } catch (e) {
      showSnackBar(Colors.red, 'Unknown error: $e');
    }
  }

  showSnackBar(Color color, String text) {
    return _scaffoldKey.currentState.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: ContinuousRectangleBorder(
            borderRadius: BorderRadius.circular(30.0)),
        content: Text(
          text,
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }

  _joinMeeting() async {
//    String serverUrl =
//    serverText.text?.trim()?.isEmpty ?? "" ? null : serverText.text;

    try {
      var options = JitsiMeetingOptions()
        ..room = mob
//        ..serverURL = serverUrl
        ..subject = "ZeroPassMeet"
        ..userDisplayName = username
//        ..userEmail = emailText.text
        ..audioOnly = false
        ..audioMuted = false
        ..videoMuted = false;

      debugPrint("JitsiMeetingOptions: $options");
      await JitsiMeet.joinMeeting(options,
          listener: JitsiMeetingListener(onConferenceWillJoin: ({message}) {
            debugPrint("${options.room} will join with message: $message");
          }, onConferenceJoined: ({message}) {
            debugPrint("${options.room} joined with message: $message");
          }, onConferenceTerminated: ({message}) {
            debugPrint("${options.room} terminated with message: $message");
          }));
    } catch (error) {
      debugPrint("error: $error");
    }
  }

  void _onConferenceWillJoin({message}) {
    debugPrint("_onConferenceWillJoin broadcasted with message: $message");
  }

  void _onConferenceJoined({message}) {
    debugPrint("_onConferenceJoined broadcasted with message: $message");
  }

  void _onConferenceTerminated({message}) {
    debugPrint("_onConferenceTerminated broadcasted with message: $message");
  }

  _onError(error) {
    debugPrint("_onError broadcasted: $error");
  }
}
