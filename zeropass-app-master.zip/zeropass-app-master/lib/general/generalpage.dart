import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_mobile_vision/flutter_mobile_vision.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropass/checkup/Chatintro.dart';
import 'package:zeropass/helpers/adddetails.dart';
import 'package:zeropass/pass/passpage.dart';
import 'package:zeropass/residence/residencepage.dart';
import 'package:zeropass/travel/travelhistorypage.dart';

class GeneralPage extends StatefulWidget {
  @override
  _GeneralPageState createState() => _GeneralPageState();
}

class _GeneralPageState extends State<GeneralPage> {
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final dbRef = FirebaseDatabase.instance.reference();
  StreamSubscription<Event> _counterSubscription;
  StreamSubscription<Event> _counterSubscription1;
  StreamSubscription<Event> _counterSubscription2;

  bool isLocationAdded = true, shoStatusBoard = false;
  String district, taluk, token, mob, healthText, healthTime;
  bool containment, quarantine;
  double lat, long;

  int _cameraFace = FlutterMobileVision.CAMERA_FRONT;
  Size _previewFace;

  _checkLocationDetail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    isLocationAdded = prefs.getBool('isLocationAdded') ?? false;
    shoStatusBoard = isLocationAdded;
    if (shoStatusBoard) {
      _getUserPath();
    }
    setState(() {});
  }

  _getUserPath() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var dst = prefs.getString('district');
    var tlk = prefs.getString('taluk');
    _getStatus(dst, tlk);
    _checkHealthChange(dst, tlk);
//    _checkContainmentUpdate(dst, tlk);
  }

  _checkHealthChange(String dst, String tlk) async {
//    _counterSubscription1 =
    dbRef
        .child('Regions/$dst/$tlk/Users/$token/Status')
        .onValue
        .listen((event) {
      _getHealth();
    });
  }

//  _checkContainmentUpdate(String dst, String tlk) async {
////    _counterSubscription2 =
//    dbRef.child('Regions/$dst/$tlk/Polygons').onValue.listen((event) {
//      _getStatus(dst, tlk);
//    });
//  }

  _getStatus(String dst, String tlk) async {
//    _counterSubscription =
    dbRef.child('Regions/$dst/$tlk/Users/$token').onValue.listen((event) {
      taluk = tlk;
      district = dst;
      lat = event.snapshot.value['Lat'];
      long = event.snapshot.value['Long'];
      mob = event.snapshot.value['Mob'].toString();
      containment = event.snapshot.value['Containment'];
      quarantine = event.snapshot.value['Quarantine'];
      AddDetails().quarantine(quarantine);
      _checkContainment(
          dst, tlk, event.snapshot.value['Lat'], event.snapshot.value['Long']);
    });
  }

  _getHealth() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      healthText = prefs.getString('healthText');
      healthTime = prefs.getString('healthTime');
    });
  }

  _checkContainment(String dst, String tlk, double lat, double long) async {
    await dbRef
        .child('Regions/$dst/$tlk/Polygon')
        .onValue
        .listen((event) async {
      var data = event.snapshot.value ?? {};
      List zoneNames = [];
      List zones = [];
      data.forEach((key, value) {
        zoneNames.add(key);
        zones.add(value);
      });
      var found = false;
      for (var l in zones) {
//        print(l);
        List<LatLng> ll = [];
        for (var i in l) {
          ll.add(LatLng(i[1], i[0]));
        }
        found = await _checkIfValidMarker(LatLng(lat, long), ll);
        if (found == true) {
          break;
        }
      }
      _setContainment(dst, tlk, found);
    });
    setState(() {});
  }

  _setContainment(String dst, String tlk, bool isfound) async {
    dbRef
        .child('Regions/$dst/$tlk/Users/$token')
        .update({'Containment': isfound});
  }

  _getDeviceToken() async {
    var t = await _messaging.getToken();
    token = t.toString();
//    print(token);
    _checkLocationDetail();
  }

  initMobileVision() {
    FlutterMobileVision.start().then((previewSizes) => setState(() {
          _previewFace = previewSizes[_cameraFace].first;
        }));
  }

  @override
  void initState() {
    _getDeviceToken();
    initMobileVision();
    _getHealth();
    super.initState();
  }

  @override
  void dispose() {
    if (_counterSubscription != null) {
      _counterSubscription.cancel();
    }
    if (_counterSubscription1 != null) {
      _counterSubscription1.cancel();
    }
    if (_counterSubscription2 != null) {
      _counterSubscription2.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        children: [
          verifyQuarantine(),
          setLocationNotification(),
          statusBoard(),
          certificate(),
          SizedBox(
            height: 24.0,
          ),
          checkup(),
          SizedBox(
            height: 24.0,
          ),
//          instructions(),
          SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  verifyQuarantine() {
    var timeChecker = int.parse(DateFormat('H').format(DateTime.now()));
    return Visibility(
      visible: (quarantine == true) &&
          (10 == timeChecker ||
              12 == timeChecker ||
              14 == timeChecker ||
              16 == timeChecker),
      child: Column(
        children: [
          InkWell(
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 4.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    offset: Offset(2.0, 2.0),
                    blurRadius: 4.0,
                  ),
                ],
              ),
              child: ListTile(
                trailing: ClipRRect(
                  borderRadius: BorderRadius.circular(16.0),
                  child: Image.asset(
                    "assets/images/general/verify.jpg",
                  ),
                ),
                title: Text(
                  'Click here to verify Yourself',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        'You should verify once during each intervals shown below:'),
                    Text('9-10 AM, 12-1 PM, 2-3 PM, 4-5 PM'),
                    Text(
                      '\nNote:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Touch on your face to get verified.',
                      style: TextStyle(
                        color: Colors.cyan.shade800,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            onTap: () async {
              Position position = await Geolocator()
                  .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
              var time = int.parse(DateFormat('H').format(DateTime.now()));
              if (10 == time || 12 == time || 14 == time || 16 == time) {
                List<Face> faces = [];
                try {
                  faces = await FlutterMobileVision.face(
                    flash: false,
                    autoFocus: true,
                    multiple: true,
                    showText: false,
                    preview: _previewFace,
                    camera: _cameraFace,
                    fps: 15.0,
                  );
                  if (faces.length == 1) {
                    double distanceInMeters = await Geolocator()
                        .distanceBetween(
                            position.latitude, position.longitude, lat, long);
                    print(distanceInMeters);
                    String date = DateTime.now().toString();
                    String d = date;
                    date = date.replaceAll(" ", "");
                    date = date.replaceAll("-", "");
                    date = date.replaceAll(":", "");
                    date = date.replaceAll(".", "");
                    dbRef
                        .child('Regions/$district/$taluk/QuarantineLogs/$token')
                        .update({date: d}).catchError((e) {});
                    if (distanceInMeters > 500) {
                      String date = DateTime.now().toString();
                      String d = date;
                      date = date.replaceAll(" ", "");
                      date = date.replaceAll("-", "");
                      date = date.replaceAll(":", "");
                      date = date.replaceAll(".", "");
                      double latitude = position.latitude;
                      double longitude = position.longitude;
                      dbRef
                          .child(
                              'Regions/$district/$taluk/Breaks/QuarantineBreak/$token')
                          .update({
                        'Mob': mob,
                        date: {'Lat': latitude, 'Long': longitude, 'Time': d}
                      }).then((value) {
                        Scaffold.of(context).showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: Colors.red,
                            shape: ContinuousRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0)),
                            content: Text(
                              'Found Quarantine Break !\nImmediately Get In Home',
                              textAlign: TextAlign.center,
                            ),
                            duration: Duration(seconds: 3),
                          ),
                        );
                      }).catchError((e) {
                        Scaffold.of(context).showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: Colors.red,
                            shape: ContinuousRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0)),
                            content: Text(
                              'Found Quarantine Break !\nImmediately Get In Home',
                              textAlign: TextAlign.center,
                            ),
                            duration: Duration(seconds: 3),
                          ),
                        );
                      });
                    } else {
                      Scaffold.of(context).showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: Colors.teal,
                          shape: ContinuousRectangleBorder(
                              borderRadius: BorderRadius.circular(30.0)),
                          content: Text(
                            'Good\nPlease Continue In Home',
                            textAlign: TextAlign.center,
                          ),
                          duration: Duration(seconds: 3),
                        ),
                      );
                    }
                  } else {
                    Scaffold.of(context).showSnackBar(
                      SnackBar(
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Colors.cyan.shade800,
                        shape: ContinuousRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0)),
                        content: Text(
                          'Found Multiple Faces !\nTry Again',
                          textAlign: TextAlign.center,
                        ),
                        duration: Duration(seconds: 3),
                      ),
                    );
                  }
                } on Exception {
                  faces.add(new Face(-1));
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: Colors.red,
                      shape: ContinuousRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0)),
                      content: Text(
                        'Verification Failed !\nTry Again',
                        textAlign: TextAlign.center,
                      ),
                      duration: Duration(seconds: 3),
                    ),
                  );
                }
              } else {
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: Colors.cyan.shade800,
                    shape: ContinuousRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0)),
                    content: Text(
                      'You cannot verify now !\nCome in time',
                      textAlign: TextAlign.center,
                    ),
                    duration: Duration(seconds: 3),
                  ),
                );
              }
            },
          ),
          SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  setLocationNotification() {
    return Visibility(
      visible: !isLocationAdded,
      child: Column(
        children: [
          InkWell(
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 4.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    offset: Offset(2.0, 2.0),
                    blurRadius: 4.0,
                  ),
                ],
              ),
              child: ListTile(
                leading: Image.asset(
                  "assets/images/general/residence.jpg",
                ),
                contentPadding: EdgeInsets.zero,
                title: Text(
                  'Add Resident Location',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text('Make sure to add location from your home'),
              ),
            ),
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ResidencePage(),
                ),
              );
              _checkLocationDetail();
            },
          ),
          SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  statusBoard() {
    return Visibility(
      visible: shoStatusBoard,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 16.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  offset: Offset(2.0, 2.0),
                  blurRadius: 4.0,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: MediaQuery.of(context).size.width / 1.5,
                    child: Image.asset(
                      "assets/images/general/status.jpg",
                      fit: BoxFit.fitWidth,
                      colorBlendMode: BlendMode.colorBurn,
                    ),
                  ),
                ),
                Text(
                  'Status Board',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16.0,
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Row(
                  children: [
                    Flexible(
                      flex: 3,
                      child: Text(
                        'Zone Name:',
                      ),
                    ),
                    SizedBox(
                      width: 8.0,
                    ),
                    Flexible(
                      flex: 2,
                      child: taluk == null
                          ? linearProgress()
                          : Text(
                              taluk,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.teal.shade800,
                              ),
                            ),
                    )
                  ],
                ),
                SizedBox(
                  height: 8.0,
                ),
                Row(
                  children: [
                    Flexible(
                      flex: 3,
                      child: Text(
                        'Regional Status:',
                      ),
                    ),
                    SizedBox(
                      width: 8.0,
                    ),
                    Flexible(
                      flex: 2,
                      child: containment == null
                          ? linearProgress()
                          : Text(
                              containment ? 'Containment Zone' : 'Safe Zone',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: containment
                                    ? Colors.red.shade800
                                    : Colors.teal.shade800,
                              ),
                            ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8.0,
                ),
                Row(
                  children: [
                    Flexible(
                      flex: 1,
                      child: Text(
                        'Quarantine Status:',
                      ),
                    ),
                    SizedBox(
                      width: 8.0,
                    ),
                    Flexible(
                      flex: 1,
                      child: quarantine == null
                          ? linearProgress()
                          : Text(
                              quarantine
                                  ? 'In Quarantine'
                                  : 'Not In Quarantine',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: quarantine
                                    ? Colors.red.shade800
                                    : Colors.teal.shade800,
                              ),
                            ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8.0,
                ),
                Row(
                  children: [
                    Flexible(
                      flex: 5,
                      child: Text(
                        'Health Status:',
                      ),
                    ),
                    SizedBox(
                      width: 8.0,
                    ),
                    Flexible(
                      flex: 12,
                      child: Text(
                        healthText != null
                            ? healthText
                            : 'No health status found',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: healthText != null
                              ? Colors.teal.shade800
                              : Colors.red.shade800,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8.0,
                ),
                Row(
                  children: [
                    Flexible(
                      flex: 1,
                      child: Text(
                        'Last Health Checkup:',
                      ),
                    ),
                    SizedBox(
                      width: 8.0,
                    ),
                    Flexible(
                      flex: 1,
                      child: Text(
                        healthTime != null ? healthTime : 'No history found',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: healthTime != null
                              ? Colors.teal.shade800
                              : Colors.red.shade800,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  certificate() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(
          child: editTravelHistory(),
        ),
        SizedBox(
          width: 8.0,
        ),
        Flexible(
          child: getQR(),
        ),
      ],
    );
  }

  editTravelHistory() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: InkWell(
        splashColor: Colors.red.shade800,
        child: Column(
          children: [
            SizedBox(
              height: 8.0,
            ),
            Text(
              "Travel History",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Image.asset(
                "assets/images/general/travel.jpg",
                fit: BoxFit.fill,
              ),
            ),
          ],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => TravelHistoryPage(),
          ),
        ),
      ),
    );
  }

  getQR() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: InkWell(
        splashColor: Colors.red.shade800,
        child: Column(
          children: [
            SizedBox(
              height: 8.0,
            ),
            Text(
              "Get Your Pass",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Image.asset(
                "assets/images/general/pass.jpg",
                fit: BoxFit.fill,
              ),
            ),
          ],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PassPage(),
          ),
        ),
      ),
    );
  }

  checkup() {
    return InkWell(
        splashColor: Colors.blueAccent.shade700,
        borderRadius: BorderRadius.circular(16.0),
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
          padding: EdgeInsets.symmetric(horizontal: 4.0),
//      height: 200,
//      width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                offset: Offset(2.0, 2.0),
                blurRadius: 4.0,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width / 3,
                    child: Column(
                      children: [
                        Text(
                          "Take A Daily Health Check-up",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width / 2.5,
                    child: Hero(
                      tag: 'checkup',
                      child: Image.asset(
                        "assets/images/general/checkup.jpg",
                        fit: BoxFit.fitWidth,
                        colorBlendMode: BlendMode.colorBurn,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => Chatintro(),
            ),
          );
          _getHealth();
          print('health calling');
        });
  }

//  instructions() {
//    return ListView(
////      padding: EdgeInsets.symmetric(horizontal: 4.0),
//      primary: false,
//      shrinkWrap: true,
//      children: [
//        Text(
//          '- Basic Instructions -',
//          style: TextStyle(
//            fontWeight: FontWeight.bold,
//            fontSize: 15,
//          ),
//          textAlign: TextAlign.center,
//        ),
//        SizedBox(
//          height: 4.0,
//        ),
//        Container(
//          margin: EdgeInsets.symmetric(vertical: 6.0),
//          padding: EdgeInsets.symmetric(vertical: 12.0),
//          decoration: BoxDecoration(
//            color: Colors.white,
//            borderRadius: BorderRadius.circular(12.0),
//            boxShadow: [
//              BoxShadow(
//                color: Colors.black.withOpacity(0.1),
//                offset: Offset(2.0, 2.0),
//                blurRadius: 4.0,
//              ),
//            ],
//          ),
//          child: ListTile(
//            leading: Image.asset("assets/images/numbers/1.jpg"),
//          ),
//        ),
//        Container(
//          margin: EdgeInsets.symmetric(vertical: 4.0),
//          padding: EdgeInsets.symmetric(vertical: 12.0),
//          decoration: BoxDecoration(
//            color: Colors.white,
//            borderRadius: BorderRadius.circular(12.0),
//            boxShadow: [
//              BoxShadow(
//                color: Colors.black.withOpacity(0.1),
//                offset: Offset(-2.0, 2.0),
//                blurRadius: 4.0,
//              ),
//            ],
//          ),
//          child: ListTile(
//            trailing: Image.asset("assets/images/numbers/2.jpg"),
//          ),
//        ),
//        Container(
//          margin: EdgeInsets.symmetric(vertical: 4.0),
//          padding: EdgeInsets.symmetric(vertical: 12.0),
//          decoration: BoxDecoration(
//            color: Colors.white,
//            borderRadius: BorderRadius.circular(12.0),
//            boxShadow: [
//              BoxShadow(
//                color: Colors.black.withOpacity(0.1),
//                offset: Offset(2.0, 2.0),
//                blurRadius: 4.0,
//              ),
//            ],
//          ),
//          child: ListTile(
//            leading: Image.asset("assets/images/numbers/3.jpg"),
//          ),
//        ),
//        Container(
//          margin: EdgeInsets.symmetric(vertical: 4.0),
//          padding: EdgeInsets.symmetric(vertical: 12.0),
//          decoration: BoxDecoration(
//            color: Colors.white,
//            borderRadius: BorderRadius.circular(12.0),
//            boxShadow: [
//              BoxShadow(
//                color: Colors.black.withOpacity(0.1),
//                offset: Offset(-2.0, 2.0),
//                blurRadius: 4.0,
//              ),
//            ],
//          ),
//          child: ListTile(
//            trailing: Image.asset("assets/images/numbers/4.jpg"),
//          ),
//        ),
//      ],
//    );
//  }

  linearProgress() {
    return LinearProgressIndicator(
      backgroundColor: Colors.black.withOpacity(0.2),
      valueColor: AlwaysStoppedAnimation<Color>(
        Colors.teal.shade800,
      ),
//      value: 0.8,
    );
  }

  _checkIfValidMarker(LatLng tap, List<LatLng> vertices) {
    int intersectCount = 0;
    for (int j = 0; j < vertices.length - 1; j++) {
      if (rayCastIntersect(tap, vertices[j], vertices[j + 1])) {
        intersectCount++;
      }
    }
    print(((intersectCount % 2) == 1));
    return ((intersectCount % 2) == 1); // odd = inside, even = outside;
  }

  bool rayCastIntersect(LatLng tap, LatLng vertA, LatLng vertB) {
    double aY = vertA.latitude;
    double bY = vertB.latitude;
    double aX = vertA.longitude;
    double bX = vertB.longitude;
    double pY = tap.latitude;
    double pX = tap.longitude;

    if ((aY > pY && bY > pY) || (aY < pY && bY < pY) || (aX < pX && bX < pX)) {
      return false; // a and b can't both be above or below pt.y, and a or
      // b must be east of pt.x
    }

    double m = (aY - bY) / (aX - bX); // Rise over run
    double bee = (-aX) * m + aY; // y = mx + b
    double x = (pY - bee) / m; // algebra is neat!

    return x > pX;
  }
}
