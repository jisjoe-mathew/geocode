import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:barcode_scan/barcode_scan.dart';
import '../screens/qr_code.dart';

String tokens;

class QrScanner extends StatefulWidget {
  var qrResult;

  QrScanner(this.qrResult);

  @override
  _QrScannerState createState() => _QrScannerState();
}

class _QrScannerState extends State<QrScanner> {
  final databaseReference = FirebaseDatabase.instance.reference();

  var parsedJson;
  double lat;
  double lng;
  var fetchedUserData;
  String checkingTime;
  DateTime datess = DateTime.now();

  String district;
  String taluk;
  String tokenID;
  bool containtment;

  Future _retriveUserDetails() async {
    parsedJson = json.decode(widget.qrResult);
    if (parsedJson['token'] != null && parsedJson['token'] != '') {
      district = parsedJson['dst'];
      taluk = parsedJson['tlk'];
      tokenID = parsedJson['token'];
      print(parsedJson['token']);
      print(district);
      print(taluk);
      checkTimeDelay();
    }

    else
      {
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
        print("hidfhkjhfjh");
      }
  }

  checkTimeDelay() async {
    var issueTime = DateTime.parse(parsedJson['timestamp']);
    var difference = (DateTime.now()).difference(issueTime).inMinutes;
    print(parsedJson['timestamp']);
    if (difference >100) {
      _showTimeExpiredDialog();
    } else {
      setState(() {
        _getUserCompeleteData();
      });
    }
  }

  Future _getUserCompeleteData() async {
    databaseReference
        .child('Regions/$district/$taluk/Users/$tokenID')
        .once()
        .then((DataSnapshot snapshot) {
      print('Value : ${snapshot.value}');
      print('Key : ${snapshot.key.length}');
      fetchedUserData = snapshot.value;

      print(fetchedUserData['Containment']);

      if (fetchedUserData['Containment'] || fetchedUserData['Quarantine']) {
//
        _showUserContainmentStatusDialog();
      } else {
        _showSafeDialog();
      }
    });
  }

  Future getCurrentLocation() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    lat = position.latitude;
    lng = position.longitude;

    checkingTime = DateTime.now().toString();
    checkingTime = checkingTime.replaceAll(" ", "");
    checkingTime = checkingTime.replaceAll("-", "");
    checkingTime = checkingTime.replaceAll(":", "");
    checkingTime = checkingTime.replaceAll(".", "");
  }

  uploadUserViloationData(String mob, String idtoken, String name, double latCo,
      double lngCo, String checkingScanTime) {
//     print(Mob);
//     print(idtoken);
//     print(name);
//     print(latCo);
//     print(lngCo);
//     print(checkingScanTime);

    databaseReference
        .child(
            "Regions/$district/$taluk/CasesRegistered/$tokenID/$checkingTime")
        .update({
      'name': '$name',
      'Time': '$datess',
      'Lat': "$latCo",
      'Long': '$lngCo',
    });

    databaseReference
        .child("Regions/$district/$taluk/CasesRegistered/$tokenID")
        .update({'Mob': '$mob'});
  }

  void initState() {
    getCurrentLocation();

    scanQRCode() async {
      String codeSanner = await BarcodeScanner.scan(); //barcode scnne
      var qrCodeResult = codeSanner;
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 350,
      child: Card(
        elevation: 20,
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 10,
            ),
            Container(
                width: MediaQuery.of(context).size.width / 2,
                child: Image.asset("assets/images/map.png")),
            Container(
              padding: EdgeInsets.all(8),
              child: Text(
                widget.qrResult,
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            RaisedButton(
              padding: EdgeInsets.fromLTRB(60, 17, 60, 17),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
              color: Colors.purple[800],
              onPressed: () {
                _retriveUserDetails();
              },
              child: Text(
                "More",
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTimeExpiredDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 500,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
//                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.height * .2,
                      child: Center(
                        child: FittedBox(
                            child: Image.asset("assets/images/scan.png")),
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Center(
                        child: Text(
                      'Status : ' 'Time Expired',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    )),
                    SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: 70,
                    ),
                    SizedBox(
                      width: 320.0,
                      child: RaisedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          setState(() {
                            widget.qrResult = 'Please Scan QR Code';
                          });
                        },
                        child: Text(
                          "Close",
                          style: TextStyle(color: Colors.white),
                        ),
                        color: Colors.purple[700],
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  void _showSafeDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 500,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
//                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.height * .2,
                      child: Center(
                        child: FittedBox(
                            child: Image.asset("assets/images/scan.png")),
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Center(
                      child: Text(
                        'Status : ' 'SAFE',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.green),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'District : ' + district,
                        style:
                            TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'Taluk : ' + taluk,
                        style:
                            TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ),
                    SizedBox(
                      height: 70,
                    ),
                    SizedBox(
                      width: 320.0,
                      child: RaisedButton(
                        onPressed: () {

                          Navigator.of(context).pop();
                          setState(() {
                            widget.qrResult = 'Please Scan QR Code';
                          });
                        },
                        child: Text(
                          "Close",
                          style: TextStyle(color: Colors.white),
                        ),
                        color: Colors.purple[700],
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  void _showUserContainmentStatusDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 500,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
//                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.height * .2,
                      child: Center(
                        child: FittedBox(
                            child: Image.asset("assets/images/scan.png")),
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Center(
                      child: Text(
                        'Status : ' 'UNSAFE',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.red),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'District : ' + district,
                        style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'Taluk : ' + taluk,
                        style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ),
                    SizedBox(
                      height: 70,
                    ),
                    SizedBox(
                      width: 320.0,
                      child: RaisedButton(
                        onPressed: () {
                          uploadUserViloationData(
                              fetchedUserData["Mob"],
                              parsedJson['token'],
                              fetchedUserData['Name'],
                              lat,
                              lng,
                              checkingTime);
                          Navigator.of(context).pop();
                          setState(() {
                            widget.qrResult = 'Please Scan QR Code';
                          });
                        },
                        child: Text(
                          "Register Case",
                          style: TextStyle(color: Colors.white),
                        ),
                        color: Colors.purple[700],
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

}
