import 'package:flutter/material.dart';

import '../screens/basicdata.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../screens/homepage.dart';

final _phoneController = TextEditingController();
final _codeController = TextEditingController();
var phone;



Future<bool> loginUser(String phone, BuildContext context) async {
  FirebaseAuth _auth = FirebaseAuth.instance;

  _auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: Duration(seconds: 60),
      verificationCompleted: (AuthCredential credential) async {
        Navigator.of(context).pop();

        AuthResult result = await _auth.signInWithCredential(credential);

        FirebaseUser user = result.user;

        if (user != null) {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => HomePage()));
        } else {
          print("Error");
        }

        //This callback would gets called when verification is done auto maticlly
      },
      verificationFailed: (AuthException exception) {
        print(exception);
      },
      codeSent: (String verificationId, [int forceResendingToken]) {
        showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) {
              return AlertDialog(
                title: Text("Give the code?"),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      controller: _codeController,
                    ),
                  ],
                ),
                actions: <Widget>[
                  FlatButton(
                    child: Text("Confirm"),
                    textColor: Colors.white,
                    color: Colors.purple[700],
                    onPressed: () async {
                      final code = _codeController.text.trim();
                      AuthCredential credential =
                          PhoneAuthProvider.getCredential(
                              verificationId: verificationId, smsCode: code);

                      AuthResult result =
                          await _auth.signInWithCredential(credential);

                      FirebaseUser user = result.user;

                      if (user != null) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HomePage()),);
                      } else {
                        print("Error");
                      }
                    },
                  )
                ],
              );
            });
      },
      codeAutoRetrievalTimeout: null);
}

//
//
//// Storing Sigup Data
//addStringToSF() async {
//  SharedPreferences prefs = await SharedPreferences.getInstance();
//  prefs.setString('RegisteredPhone', phone);
//}
//

class PhoneRegField extends StatelessWidget {

  @override
  Widget build(BuildContext context) {




    return Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey[200]))),
          child: TextField(
            controller: _phoneController,
            keyboardType: TextInputType.number,
            maxLength: 13,
            decoration: InputDecoration(
                prefixText: "+91",
                hintText: "       Enter Phone number",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                border: InputBorder.none),
          ),
        ),
      ],
    );
  }
}




class PhoneRegbutton extends StatelessWidget {



  @override
  Widget build(BuildContext context) {



    void submitData() {

      final enetered_num = _phoneController.text;

      if (enetered_num.isNotEmpty && enetered_num.length ==10) {



      }
      else{
        print(" please fill correct num");
      }
    }


    return ButtonTheme(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: RaisedButton(
        padding: EdgeInsets.fromLTRB(60, 17, 60, 17),
        color: Colors.purple[800],
        onPressed: () {

         phone = '+91' + _phoneController.text;
//         addStringToSF();
         loginUser(phone, context);
        },
        child: Text(
          "Register",
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
