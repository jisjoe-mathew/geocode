//import 'package:flutter/material.dart';
//statusBoard() {
//  return Container(
//    padding: EdgeInsets.all(12.0),
////      height: 200,
//    width: double.infinity,
//    decoration: BoxDecoration(
//      color: Colors.white,
//      borderRadius: BorderRadius.circular(16.0),
//      boxShadow: [
//        BoxShadow(
//          color: Colors.black.withOpacity(0.1),
//          offset: Offset(2.0, 2.0),
//          blurRadius: 4.0,
//        ),
//      ],
//    ),
//    child: Column(
//      crossAxisAlignment: CrossAxisAlignment.start,
//      children: [
//        Text(
//          'Status Board',
//          style: TextStyle(
//            fontWeight: FontWeight.bold,
//            fontSize: 15.0,
//          ),
//        ),
//        SizedBox(
//          height: 8.0,
//        ),
//        Wrap(
//          direction: Axis.horizontal,
//          children: [
//            Text(
//              'Health Status:',
//              style: TextStyle(fontSize: 16),
//            ),
//            SizedBox(
//              width: 8.0,
//            ),
//            Text(
//              'Healthy',
//              style: TextStyle(
//                fontWeight: FontWeight.bold,
//                fontSize: 16,
//                color: Colors.teal,
//              ),
//            ),
//          ],
//        ),
//        SizedBox(
//          height: 8.0,
//        ),
//        Wrap(
//          direction: Axis.horizontal,
//          children: [
//            Text(
//              'Regional Status:',
//              style: TextStyle(fontSize: 16),
//            ),
//            SizedBox(
//              width: 8.0,
//            ),
//            Text(
//              'Safe Zone',
//              style: TextStyle(
//                fontWeight: FontWeight.bold,
//                fontSize: 16,
//                color: Colors.teal,
//              ),
//            ),
//          ],
//        ),
//        SizedBox(
//          height: 8.0,
//        ),
//        Wrap(
//          direction: Axis.horizontal,
//          children: [
//            Text(
//              'Quarantine Status:',
//              style: TextStyle(fontSize: 16),
//            ),
//            SizedBox(
//              width: 8.0,
//            ),
//            Text(
//              'Not In Quarantine',
//              style: TextStyle(
//                fontWeight: FontWeight.bold,
//                fontSize: 16,
//                color: Colors.teal,
//              ),
//            ),
//          ],
//        ),
//        Row(
//          mainAxisAlignment: MainAxisAlignment.center,
//          children: [
//            Container(
//              width: MediaQuery.of(context).size.width / 2,
//              child: Image.network(
//                "https://image.freepik.com/free-vector/people-waving-hand-illustration-concept_52683-29825.jpg",
//                fit: BoxFit.fitWidth,
//                colorBlendMode: BlendMode.colorBurn,
//              ),
//            ),
//          ],
//        ),
//      ],
//    ),
//  );
//}