import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:zeropaas/screens/qr_code.dart';
import '../screens/profile.dart';
import '../screens/video_conf.dart';
import '../screens/notification.dart';
import '../screens/nearby_officers.dart';
import '../screens/add_cases.dart';


class Drawers extends StatelessWidget {


  var qrCodeResult;

  @override
  Widget build(BuildContext context) {





    return  ClipRRect(
      borderRadius: BorderRadius.vertical(top: Radius.circular(40.0)),
      child: Drawer(
        
        child: Column(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                width: MediaQuery.of(context).size.width * 5,
                child: FittedBox(
                  child: Image.network("https://image.freepik.com/free-vector/recruit-agent-analyzing-candidates_74855-4565.jpg"),
                  fit: BoxFit.fill,
                )
              ),
            ),
            Expanded(
              flex:2,
              child: ListView(children: [
                ListTile(
                  title: Text("Home"),
                  trailing: Icon(Icons.home),
                  onTap: () {
                    Navigator.of(context).pop();
                  },
                ),
                ListTile(
                  title: Text("Profile"),
                  trailing: Icon(Icons.person),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Profile() ),);

//
                  },
                ),
                ListTile(
                  title: Text("Scan Pass"),
                  trailing: Icon(Icons.scanner),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ScanPage()),);

//
                  },
                ),

                ListTile(
                  title: Text("Add Cases"),
                  trailing: Icon(Icons.border_color),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              MLText()),);

//
                  },
                ),
                ListTile(
                  title: Text("Notifications"),
                  trailing: Icon(Icons.add),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                            BreakNotifications()  ),);
                  },
                ),
                ListTile(
                  trailing: Icon(Icons.location_on),
                  title: Text("Nearby Officers"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              MapsPage()),);

                  },
                ),
                ListTile(
                  trailing: Icon(Icons.video_call),
                  title: Text("Video Conference "),
                  onTap: () {

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ZeroMeet()),);



                  },
                ),
                ListTile(
                  trailing: Icon(Icons.exit_to_app),
                  title: Text("Signout"),
                  onTap: () {
                    FirebaseAuth.instance.signOut();
                  },
                ),

              ]),
            )
          ],
        ),
      ),
    );

  }
}


