import 'package:flutter/material.dart';
import "package:zeropaas/auth/auth.dart";
import 'package:flutter/services.dart' ;
import 'package:cron/cron.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropaas/screens/Chata.dart';
import 'package:zeropaas/screens/Chatb.dart';
import 'package:zeropaas/screens/Chatc.dart';
import 'package:zeropaas/screens/Chatd.dart';
import 'package:zeropaas/screens/Chate.dart';
import 'package:zeropaas/screens/Chatf.dart';
import 'package:zeropaas/screens/Chatg.dart';
import 'package:zeropaas/screens/Chath.dart';
import 'package:zeropaas/screens/Chatintro.dart';





void main()
{
  var cron = new Cron();
  cron.schedule(new Schedule.parse('*/3 * * * *'), () async {
    _getOfficerLocation();
    print('every three minutes');
  });

  runApp(MyApp());
}


var lat;
var lng;

_getOfficerLocation()async
{
  Position position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  print(position);
  lat = position.latitude;
  lng = position.longitude;

  _fetchStorageData();
}
//
_fetchStorageData() async
{
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String name = prefs.getString('Name');
  String taluk = prefs.getString('Taluk');
  String district = prefs.getString('District');
  String tokenID = prefs.getString('TokenID');
  print(name);
  print(taluk);
  print(tokenID);
  print(district);

  if(name !=null && taluk!=null && district  != null && tokenID !=null )
    {
      databaseReference.child("Regions/$district/PoliceLocations/$name").set({

        'Lat': "$lat",
        'Lng': '$lng',
        'Token': '$tokenID',
      });
    }
}



final databaseReference = FirebaseDatabase.instance.reference();

class MyApp extends StatelessWidget {


  final FirebaseMessaging _fcm = FirebaseMessaging();

  @override
  Widget build(BuildContext context) {


    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    return MaterialApp(
        routes: <String, WidgetBuilder>{
           '/chatintro': (BuildContext context) => Chatintro(),
          '/chata': (BuildContext context) => Chata(),
          '/chatb': (BuildContext context) => Chatb(),
          '/chatc': (BuildContext context) => Chatc(),
          '/chatd': (BuildContext context) => Chatd(),
          '/chate': (BuildContext context) => Chate(),
          '/chatf': (BuildContext context) => Chatf(),
          '/chatg': (BuildContext context) => Chatg(),
          '/chath': (BuildContext context) => Chath(),
        },
      debugShowCheckedModeBanner: false,

      title: 'Flutter Demo',
      theme: ThemeData(


        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthService().handleAuth()
    );
  }
}


