import 'package:flutter/material.dart';

class PersonalData{

   final String name;
   final String address;
   final String regPhoneNumber;
   final String district;
   final String email;
   final String designations;
   final String station;
   final String sex;


   PersonalData({this.name,this.address, this.regPhoneNumber, this.district,this.email, this.designations,this.station, this.sex});
}
