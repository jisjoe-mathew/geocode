
import 'package:flutter/material.dart';

class Designations {
  const Designations(this.name, this.icon);
  final String name;
  final Icon icon;

}