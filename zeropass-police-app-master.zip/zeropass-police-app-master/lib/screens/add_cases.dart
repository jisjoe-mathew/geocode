import 'dart:io';
import 'dart:math';
import '../models/designation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';


class MLText extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage> {
  final databaseReference = FirebaseDatabase.instance.reference();
  final vehicleNum = TextEditingController();


  String name = "";
  String address;
  String stationName = "";
  String rank = '';
  String email;
  String _datas ;
  String datainfo;
  DateTime period = DateTime.now();

  File pickedImage;

  bool isImageLoaded = false;

  Future pickImage() async {
    var tempStore = await ImagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      pickedImage = tempStore;
      isImageLoaded = true;
    });
  }

  Future readText() async {
    FirebaseVisionImage ourImage = FirebaseVisionImage.fromFile(pickedImage);
    TextRecognizer recognizeText = FirebaseVision.instance.textRecognizer();
    VisionText readText = await recognizeText.processImage(ourImage);
    var tt = readText.text.toString().replaceAll("\n", ' ');

    final _t=tt.substring(tt.indexOf("No."),tt.indexOf("Transport"));


    getDetails(_t.toString());
//    print("++++++_+"+  _t.toString());







    for (TextBlock block in readText.blocks) {
      for (TextLine line in block.lines) {
        for (TextElement word in line.elements) {
//          print(word.text);



//
//        if(word.text)
//          {
//            print("hi");
//          }

        }

      }

    }
//
//    dtaas = readText.text as String;
//
//    print(dtaas.toString());
//    print(dtaas.toString());




  }


 Designations selectedUser;





  _uploadData()
  {
    databaseReference.child("Regions/$address/$email/Cases/${vehicleNum.text}").set({

//      'Name':'$datainfo',
//      'TimeStamp':'$period',
      'Type': "NO helmet",



    });


  }

  Future fetchUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getString('Name')??"";
    email = prefs.getString('Taluk')??"";
    address = prefs.getString('District')??"";
    rank = prefs.getString('Designation');
    stationName = prefs.getString('StaionName')??"";


    print(stationName);

    setState(() {});

  }

 List<Designations> users = <Designations>[
   const Designations(
       ' Over Speed',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       'No Helmet',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       'Over Load',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       ' Traffic Violation ',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       'No seat Belt',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       'No Insurance',
       Icon(
         Icons.star,
         color: Colors.grey,
       )),
   const Designations(
       'No Accessories',
       Icon(
         Icons.star,
         color: Colors.grey,
       ))
 ];


  Future decode() async {
    FirebaseVisionImage ourImage = FirebaseVisionImage.fromFile(pickedImage);
    BarcodeDetector barcodeDetector = FirebaseVision.instance.barcodeDetector();
    List barCodes = await barcodeDetector.detectInImage(ourImage);

    for (Barcode readableCode in barCodes) {
//      print(readableCode.displayValue);
    }
  }


// void startNewTransaction(BuildContext ctx) {
//   showModalBottomSheet(
//
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
//       ),
//       context: ctx,
//       builder: (_) {
//         return Container(
//             height: MediaQuery.of(context).size.height * 0.50,
//             decoration: new BoxDecoration(
//               color: Colors.white,
//               borderRadius: new BorderRadius.only(
//                 topLeft: const Radius.circular(25.0),
//                 topRight: const Radius.circular(25.0),
//               ),
//             ),
//
//             child: Container(
//                 padding: EdgeInsets.all(5),
//                 child: QrScanner( qrCodeResult))
//
//         );
//       });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Add Cases'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              SizedBox(height: 40.0),
              isImageLoaded
                  ? Center(
                child: Card(
                  
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Container(
                        height: 150.0,
                        width: 150.0,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: FileImage(pickedImage), fit: BoxFit.cover))),
                  ),
                ),
              )
                  : Container(),
              SizedBox(height: 10.0),
//            RaisedButton(
//              child: Text('Pick an image'),
//              onPressed: pickImage,
//            ),
//            SizedBox(height: 10.0),
//            RaisedButton(
//              child: Text('Read Text'),
//              onPressed: readText,
//            ),
//            RaisedButton(
//              child: Text('Read Bar Code'),
//              onPressed: decode,
//            ),



              Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[

                    InkWell(
                      onTap: (){


                        pickImage();


//
//                      var re = RegExp(r'(?<=Name)(.*)(?=Address)');
//
//                      var match = re.firstMatch(dtaas);
//                      if (match != null) print(match.group(0));
                      },

                      child: Card(
                        elevation: 10,
                        child: Container(
                          child: Column(
                            children: <Widget>[

                              SizedBox(
                                height: 20,
                              ),

                              Text("Upload License",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 16),),
                              Flexible(child: Image.network("https://image.freepik.com/free-vector/qr-code-scanning-with-characters_23-2148612479.jpg"))
                            ],
                          ),

                          height: 120,
                          width: 140,

                        ),
                      ),
                    ),
                    SizedBox(
                        width: 20
                    ),

                    InkWell(
                      onTap: ()
                      {
                        readText();

                      },

                      child: Card(
                        elevation: 10,
                        child: Container(
                          child: Column(
                              children: <Widget>[

                                SizedBox(
                                  height: 20,
                                ),

                                Text("Read",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 16),),
                                Flexible(child: Image.network("https://image.freepik.com/free-vector/illustration-envelope_53876-5849.jpg"))
                              ]
                          ),

                          height: 120,
                          width: 140,

                        ),
                      ),
                    ),



                  ],
                ),
              ),

              Padding(

                padding: const EdgeInsets.fromLTRB(30, 5, 30, 5),
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: TextField(
controller: vehicleNum,
                      decoration: InputDecoration(
                        icon: Icon(Icons.directions_car),
                          border: InputBorder.none,
                          hintText: 'Enter Vehicle Number'
                      ),
                    )
                    ,
                  ),

                ),
              ),
//
//              Padding(
//                padding: const EdgeInsets.fromLTRB(30, 5, 30, 5),
//                child: Card(
//                  child: Padding(
//                    padding: EdgeInsets.all(10),
//                    child: TextField(
//
//                      decoration: InputDecoration(
//                          icon: Icon(Icons.directions_car),
//                          border: InputBorder.none,
//                          hintText: 'Enter Vehicle Number'
//                      ),
//                    )
//                    ,
//                  ),
//
//                ),
//              )
              Padding(
                padding: EdgeInsets.fromLTRB(30, 5, 30, 5),
                child: Card(
                  child: Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                        border: Border(
                            bottom: BorderSide(
                                color:
                                Colors.grey[200]))),
                    child: Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          "Complaints",
                          style: TextStyle(
                              color: Colors.grey[600], fontSize: 18),
                        ),
                        SizedBox(
                          width: 30,
                        ),
                        DropdownButton<Designations>(
                          hint: Text("Select Complaint"),
                          value: selectedUser,
                          onChanged:
                              (Designations Value) {

                            setState(() {
                              selectedUser = Value;
                              print(selectedUser.name);
                            });

                          },
                          items: users
                              .map((Designations user) {
                            return DropdownMenuItem<
                                Designations>(
                              value: user,
                              child: Row(
                                children: <Widget>[
                                  user.icon,
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    user.name,
                                    style: TextStyle(
                                        color: Colors
                                            .black),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              SizedBox(
                height: 30,
              ),

              InkWell(
                onTap: () async {
                _uploadData();
                },

                child: Container(

                  height: 70,
                  width: 250,
                  child: Card(
                    color: Colors.purple[700],
                    shape: RoundedRectangleBorder(

                      borderRadius: BorderRadius.circular(35.0),

                    ),
                    elevation: 5,
                    child: Container(

                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[


//

                          Icon(Icons.scanner, color: Colors.white,),

                          SizedBox(
                            width: 20,
                          ),

                          Text("Register",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),

//                      Flexible(child: Image.network("https://image.freepik.com/free-vector/qr-code-scanning-with-characters_23-2148612479.jpg"))
                        ],
                      ),

                      height: 180,
                      width: 140,

                    ),
                  ),
                ),
              ),
            ],



          ),
        ));
  }
  getDetails(final infod)
  {
//    print(infod);
    datainfo = infod.toString();
    print(datainfo);

  }
}



