import 'dart:convert';

import 'package:barcode_scan/barcode_scan.dart';
import 'dart:async';
import 'package:flutter/material.dart';


import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/qrbottom.dart';
import '../widgets/qrbottom.dart';
import '../widgets/qrbottom.dart';
import 'package:shared_preferences/shared_preferences.dart';


class ScanPage extends StatefulWidget {
  @override
  _ScanPageState createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {


//
//   String tokenID;
//   String districtName;
//   String talukName;
//   DateTime periodRange;
  String qrCodeResult = "";


  String taluk = "";
//  String address;
  String stationName = "";
//  String rank = '';
//  String email;



   Future fetchUserData() async {
     SharedPreferences prefs = await SharedPreferences.getInstance();
     taluk = prefs.getString('Taluk')??"";
//     email = prefs.getString('Email')??"";
//     address = prefs.getString('Address')??"";
//     rank = prefs.getString('Designation');
     stationName = prefs.getString('StaionName')??"";


     print(taluk);

     setState(() {});

   }

  void initState() {

    scanQRCode()
    async {
      String codeSanner = await BarcodeScanner.scan();
      qrCodeResult = codeSanner;
    }

    fetchUserData();
    super.initState();
  }



  void startNewTransaction(BuildContext ctx) {
    showModalBottomSheet(

        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
        ),
        context: ctx,
        builder: (_) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.50,
            decoration: new BoxDecoration(
              color: Colors.white,
              borderRadius: new BorderRadius.only(
                topLeft: const Radius.circular(25.0),
                topRight: const Radius.circular(25.0),
              ),
            ),

              child: Container(
                padding: EdgeInsets.all(5),
                  child: QrScanner( qrCodeResult))

          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        centerTitle: true,
        title: Text('Scan Pass'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(

            bottom: Radius.circular(20),

          ),
        ),
      ),


      body: Container(

        padding: EdgeInsets.all(0),
        child: Column(

//          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[


            SizedBox(
              height: 20,
            ),
            Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    children: <Widget>[
                      Flexible(child: Image.network("https://image.freepik.com/free-vector/location_53876-25530.jpg")),

                      Text(taluk +  " - -" + stationName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                    ],
                  )
                ),
              ),
            ),
            SizedBox(
              height: 40,
            ),

           Center(
             child: Container(
               height: MediaQuery.of(context).size.height * .40,

               child: FittedBox(child: Image.network("https://image.freepik.com/free-vector/qr-code-scanning-with-characters_23-2148612479.jpg")
               ),
             ),
           ),
            SizedBox(
              height: 20.0,
            ),

            Text("NOTE:   Please Scan the Qr Code by  pressing Scan Button", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey[500]),),

            SizedBox(
              height: 30,
            ),
//            RaisedButton(
//
//              color: Colors.purple[700],
//              padding: EdgeInsets.fromLTRB(150, 17, 150, 17),
//              onPressed: () async {
//
//
//                String codeSanner = await BarcodeScanner.scan();
//
//                setState(() {
//                  qrCodeResult = codeSanner;
//
//                });
//
//
//                startNewTransaction(context);
//
//              },
//
//                  child:Text(
//                    "Scan",
//                    style:
//                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
//                  ),
//
//              shape: RoundedRectangleBorder(
//
//                  borderRadius: BorderRadius.circular(20.0)),
//            )

            InkWell(
              onTap: () async {
                String codeSanner = await BarcodeScanner.scan();

                setState(() {
                  qrCodeResult = codeSanner;

                });


                startNewTransaction(context);
              },

              child: Container(

                height: 70,
                width: 250,
                child: Card(
                  color: Colors.purple[700],
                  shape: RoundedRectangleBorder(

                    borderRadius: BorderRadius.circular(35.0),

                  ),
                  elevation: 5,
                  child: Container(

                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[


//                       

                        Icon(Icons.scanner, color: Colors.white,),

                        SizedBox(
                          width: 20,
                        ),

                        Text("Scan Pass",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),

//                      Flexible(child: Image.network("https://image.freepik.com/free-vector/qr-code-scanning-with-characters_23-2148612479.jpg"))
                      ],
                    ),

                    height: 180,
                    width: 140,

                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}