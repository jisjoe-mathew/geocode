

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:dio/dio.dart';

class MapsPage extends StatefulWidget {
  MapsPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MapsPageState createState() => _MapsPageState();
}

class _MapsPageState extends State<MapsPage> {


  String taluk;
  String district;
  Map locMap;
  List keys = [];
  List values = [];

  final databaseReference = FirebaseDatabase.instance.reference();


  _fetchStorageData() async
  {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    taluk = prefs.getString('Taluk');
    district = prefs.getString('District');


    _getBreakData();
  }


  _getBreakData() {
    databaseReference
        .child("Regions/$district/PoliceLocations")
        .onValue
        .listen((event) {
      print(district);
      print(event.snapshot.value);
      locMap = event.snapshot.value;
      print(locMap);
      locMap.forEach((k, v) {
        keys.add(k);
        values.add(v);
      });

      print(locMap.length);

      print(keys[0]);
      print(values[0]['Lat']);


      for (var i = 0; i < locMap.length; i++) {
        var latit = values[i]['Lat'];
        double latpoint = double.parse(latit);
        var longi = values[i]['Lng'];
        double lngpoint = double.parse(longi);
        print(latpoint);
        print(lngpoint);
        String name = keys[i];
        final LatLng cooordi = LatLng(latpoint, lngpoint);

        print(cooordi);

        markers.add(Marker(
          markerId: MarkerId(keys[i]),

          position: cooordi,
          infoWindow:  InfoWindow(
            title: '$name',
            snippet: '',
          ),
          onTap: ()
          {

          },
          onDragEnd: (dragEndPosition) => print(dragEndPosition),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ));
      }
    });


  }



  Completer<GoogleMapController> _googleMapController = Completer();
  List<Marker> markers = [];
  LatLng latlng = LatLng(40.7128, -74.0060);

  _getPosition() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    _changeCameraPosition(position);
  }

  _changeCameraPosition(Position position) async {
    await _googleMapController.future.then((value) {
      value.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 14.0,
          tilt: 80
        ),
      ));
    });
  }



  @override
  void initState() {
    super.initState();
    _fetchStorageData();
    _getPosition();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        centerTitle: true,
        title: Text('Nearby officers'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.purple[700],
        child: Text("FIND"),
        onPressed: (){
          sendNotifi();
          setState(() {

          });
        },

      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      body: Stack(
        children: <Widget>[
          Container(

            child: GoogleMap(
              initialCameraPosition: CameraPosition(target: latlng, zoom: 14.0,tilt: 60),
              markers: Set.from(markers),
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController googleMapController) {
                _googleMapController.complete(googleMapController);

              },
              onTap: _onMapTapped
            ),
          ),

        ],
      )
    );

  }


  _onMapTapped(LatLng tappedPosition) {
    print(tappedPosition);
    setState(() {
//      Uncomment the next line if you need only one point from the map.
//      markers = [];
      markers.add(
        Marker(
          markerId: MarkerId(tappedPosition.toString()),
          position: tappedPosition,
          draggable: true,
          onDragEnd: (dragEndPosition) => print(dragEndPosition),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
      );
    });
  }

}

Future<bool>sendNotifi() async {
  var notifytoken;

  Response response = await Dio().post("https://fcm.googleapis.com/fcm/send", data:{"to" : "dncorv8Qlcw:APA91bFp1wro8Ul7IQvbjEMQEhvLabPBqfOlL7mpu1XYqjGdmvYw8OgsfRRkJoWzkewxQml3ym3wFIb6CygDrYNoz0QY9SG-eGZQIFKKPOWH9fpgWsixdAB5ypDYTjOlH3j3014zE6Mc",
    "collapse_key" : "type_a",
    "notification": {
      "title" : "ZeroPass",
      "body"  : "Incoming Messages",
      "icon"  : "ic_notification",
      "click_action" : "FLUTTER_NOTIFICATION_CLICK"
    },
    "data" : {
      "body" : "Sending Notification Body From Data",
      "title": "Notification Title from Data",
      "key_1" : "Value for key_1",
      "key_2" : "Value for key_2",
      "phone" : 'hello'
    }
  },
      options: Options(
          headers: {"Authorization" : "AAAAL5ZU4Cc:APA91bF3J4Vwf4ewxQ5Y9gonFevoXCChVGG4gfYKdn1up61VIk4ubaV463SqvsLZ3sGnCDyb-3kJhveyCQPzdFrg4yQZkifQxzppgE1r8uUq-Oh1m0Av6CSNwLye513cDu8JKM8e7CnE"},
          followRedirects: false,
          validateStatus: (status) { return status <500; }));
  if(response.statusCode == 200){
    return true;
  }
  else {
    return false;
  }


}