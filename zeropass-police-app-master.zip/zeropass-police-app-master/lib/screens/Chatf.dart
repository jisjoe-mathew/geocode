import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropaas/screens/raised_gradient_button.dart';

class Chatf extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHome(title: 'Flutter Demo Home Page');
  }
}

SharedPreferences localStorage;
String fever = "";

class MyHome extends StatefulWidget {
  MyHome({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomeState createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();

  var tmpArray = [];
  Map<String, bool> values = {
    'Diabetes': false,
    'High Blood Pressure': false,
    'Heart Disease': false,
    'Kidney/Lung Disease': false,
    'Stroke': false,
    'Reduced Immunity': false,
    'None of these': false,
  };

  getCheckboxItems() {
    values.forEach((key, value) {
      if (value == true) {
        fever = "true";
        tmpArray.add(key);
      }
    });

    // Printing all selected items on Terminal screen.
    print(tmpArray);
    // Here you will get all your selected Checkbox items.

    // Clear array after use.
    setState(() {});
  }

  Future loadMusic() async {
    player = await cache.play("mp3/c2.mp3");
  }

  @override
  void initState() {
    super.initState();
    loadMusic();
    initShared() async {
      localStorage = await SharedPreferences.getInstance();
    }

    initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        centerTitle: true,
        title: Text('Voice Assistant'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(padding: EdgeInsets.only(top: 30)),
            Text(
              "Please select your conditions",
              style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 18.0,
                  fontWeight: FontWeight.w800),
            ),
            SizedBox(
              height: 20,
            ),
            checkboxWidget(),
          ],
        ),
      ),
    );
  }

  checkboxWidget() {
    return Expanded(
      child: Column(
        children: <Widget>[
          Expanded(
            child: ListView(
              children: values.keys.map(
                    (String key) {
                  return new CheckboxListTile(
                    title: new Text(key),
                    value: values[key],
                    activeColor: Colors.pink,
                    checkColor: Colors.white,
                    onChanged: (bool value) {
                      setState(
                            () {
                          if (key == "None of these") {
                            values.forEach(
                                  (key, value) {
                                values[key] = false;
                              },
                            );
                          }
                          values[key] = value;
                        },
                      );
                    },
                  );
                },
              ).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 150.0),
            child: RaisedGradientButton(
              child: Text(
                'Next',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              gradient: LinearGradient(
                colors: <Color>[
                  Colors.purple[900],
                  Colors.purple[400],
                ],
              ),
              width: MediaQuery.of(context).size.width / 1.2,
              height: 60,
              borderRadius: 30,
              onPressed: _validate,
            ),
          )
        ],
      ),
    );
  }

  Future _validate() async {
    getCheckboxItems();
    if (fever == "") {
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red);
    } else {
      await localStorage.setString("tmmpd", json.encode(tmpArray).toString());
      player?.stop();
      Navigator.of(context).pushReplacementNamed('/chatg');
    }
  }
}