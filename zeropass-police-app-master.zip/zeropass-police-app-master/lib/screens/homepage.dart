import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import '../widgets/sendNotifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../screens/notification.dart';
import '../screens/qr_code.dart';
import '../widgets/Drawer.dart';
import '../screens/Chatintro.dart';


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();

  String name = "";
  String address;
  String stationName = "";
  String rank = '';
  String email;



  Future fetchUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getString('Name')??"";
    email = prefs.getString('Email')??"";
    address = prefs.getString('Address')??"";
    rank = prefs.getString('Designation');
    stationName = prefs.getString('StaionName')??"";


    print(stationName);

    setState(() {});

  }

  Future<bool> _onBackPressed() {
    return showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text('Are you sure?'),
        content: new Text('Do you want to exit an App'),
        actions: <Widget>[
          new GestureDetector(
            onTap: () => Navigator.of(context).pop(false),
            child: Text("NO"),
          ),
          SizedBox(height: 16),
          new GestureDetector(
            onTap: () => Navigator.of(context).pop(true),
            child: Text("YES"),
          ),
        ],
      ),
    ) ??
        false;
  }
  List adsList = [
    "https://image.freepik.com/free-vector/police-control-coronavirus_23-2148504333.jpg",
    "https://upload.wikimedia.org/wikipedia/en/1/17/Kerala_Police_Logo.png",
    "https://www.deccanherald.com/sites/dh/files/article_images/2019/11/05/Kerala%20police-1572894601.jpg",
    "https://image.freepik.com/free-vector/accident-scene-with-car-crash-highway-illustration_1308-40883.jpg",
  ];
  @override
  void initState() {
    fetchUserData();

initNotifications();

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async{
        //print('on message ${message}');

        // initialise the plugin. app_icon needs to be a added as a drawable resource to the Android head project
        await displayNotification(message);

        // _showItemDialog(message);
      },
      onResume: (Map<String, dynamic> message) async {
        print('on resume $message');
//        videoCall.getNumber(message['data']['phone'].toString());
        Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => HomePage()));
        //await displayNotification(message);
      },
      onLaunch: (Map<String, dynamic> message) {
        print('on launch $message');
        //displayNotification(message);
//        videoCall.getNumber(message['data']['phone'].toString());
        Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => HomePage()));
      },
    );
    _firebaseMessaging.requestNotificationPermissions(
        const IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
    _firebaseMessaging.getToken().then((String token) {
      assert(token != null);
      print(token);
    });
    super.initState();

  }


  initNotifications() async {
// initialise the plugin. app_icon needs to be a added as a drawable resource to the Android head project
    var initializationSettingsAndroid =
    new AndroidInitializationSettings('mipmap/ic_launcher');
    var initializationSettingsIOS = new IOSInitializationSettings(
        onDidReceiveLocalNotification: (i, string1, string2, string3) {
          print("received notifications");
        });
    var initializationSettings = new InitializationSettings(
        initializationSettingsAndroid, initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (string) {

          print("selected notification");
        });
  }

  Future displayNotification(Map<String, dynamic> message) async{
    print(message['data']);
    var androidPlatformChannelSpecifics = new AndroidNotificationDetails(
        'channelid', 'flutterfcm', 'your channel description',
        importance: Importance.Max, priority: Priority.High);
    var iOSPlatformChannelSpecifics = new IOSNotificationDetails();
    var platformChannelSpecifics = new NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(0, message['data']['title'],
        message['data']['body'], platformChannelSpecifics,
        payload: message['data']['phone']);
  }
  @override

  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Dashboard'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
      body: WillPopScope(
        onWillPop: _onBackPressed,
        child: Column(

          children: <Widget>[


            Container(
              height: 150,
              width: MediaQuery.of(context).size.width / 1,

              child: Card( child: Padding(
                child: Row(


                 children: <Widget>[
                   Text( "Welcome To ZeroPass \n      Mr " + name, style: TextStyle(fontWeight: FontWeight.bold, fontSize:17),),
                 SizedBox(
                   width: 30,
                 ),
                 Image.network("https://image.freepik.com/free-vector/woman-with-glasses-welcome-concept-landing-page_52683-22966.jpg")],
                ),
                padding: EdgeInsets.all(15),
              ),
                elevation: 5,
                margin: EdgeInsets.all(20),),
            ),

            Flexible(
              flex: 1,
              child: Container(
                height: 200,
                child: Swiper(
                  itemCount: adsList.length,
                  index: 0,
                  scrollDirection: Axis.horizontal,
                  loop: true,
                  fade: 0.5,
                  viewportFraction: 0.6,
                  scale: 0.6,
                  autoplay: true,

                  controller: SwiperController(),
                  control: SwiperControl(color: Colors.white),
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                      margin: EdgeInsets.symmetric(vertical: 6.0),
                      padding: EdgeInsets.all(4.0),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
//                      border: Border.all(width: 0, color: Colors.white),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            offset: Offset(4.0, 2.0),
                            blurRadius: 4.0,
                          ),
                        ],
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16.0),
                        child: Image.network(
                          adsList[index],
                          fit: BoxFit.fill,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Text("Features",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 28),),

            SizedBox(
              height: 10,
            ),


            Padding(
              padding: EdgeInsets.all(30),
              child: Row(
                children: <Widget>[
                  InkWell(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ScanPage()),);
                    },

                    child: Card(
                      elevation: 10,
                      child: Container(
                        child: Column(
                          children: <Widget>[

                            SizedBox(
                              height: 20,
                            ),

                            Text("Scan Pass",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                            Flexible(child: Image.network("https://image.freepik.com/free-vector/qr-code-scanning-with-characters_23-2148612479.jpg"))
                          ],
                        ),

                        height: 180,
                        width: 140,

                      ),
                    ),
                  ),
                  SizedBox(
                   width: 20
                  ),

                  InkWell(
                    onTap: ()
                    {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                BreakNotifications()  ),);
                    },

                    child: Card(
                      elevation: 10,
                      child: Container(
                        child: Column(
                          children: <Widget>[

                            SizedBox(
                              height: 20,
                            ),

                            Text("Notifications",style:  TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                            Flexible(child: Image.network("https://image.freepik.com/free-vector/illustration-envelope_53876-5849.jpg"))
                          ]
                        ),

                        height: 180,
                        width: 140,

                      ),
                    ),
                  )


                ],
              ),
            ),
            //

          ],


        ),
      ),
      drawer: Drawers(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.purple[700],
        onPressed: (){

        },
        child: IconButton(
          icon: Icon(
            Icons.chat_bubble,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      Chatintro()),);
          },
        ),
      ),
    );
  }
}


