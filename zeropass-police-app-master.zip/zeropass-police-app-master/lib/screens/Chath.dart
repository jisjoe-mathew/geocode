import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;


class Chath extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Flutter Demo Home Page');
  }
}
SharedPreferences localStorage;
var fever="",age="",tmmpa="",tmmpb="",tmmpc="",tmmpd="",tmmpe="",result="",score=0;
String uid,name,phone,gender,yob,gname,house,lm,vtc,po,dist,state,pc;

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;


  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    advancedPlayer = await AudioCache().play("mp3/high.mp3");
  }  Future loadMusicm() async {
    advancedPlayer = await AudioCache().play("mp3/medium.mp3");
  }
  Future loadMusicl() async {
    advancedPlayer = await AudioCache().play("mp3/low.mp3");
  }
  @override
  void initState() {
    super.initState();
initShared() async {
  localStorage = await SharedPreferences.getInstance();
  age=localStorage.getString("age");
  fever=localStorage.getString("fever");
  tmmpa=localStorage.getString("tmmpa");
  tmmpb=localStorage.getString("tmmpb");
  tmmpc=localStorage.getString("tmmpc");
  tmmpd=localStorage.getString("tmmpd");
  tmmpe=localStorage.getString("tmmpe");
  uid=localStorage.getString("uid")!=null?localStorage.getString("uid"):"";
  name=localStorage.getString("name")!=null?localStorage.getString("name"):"";
  phone=localStorage.getString("phone")!=null?localStorage.getString("phone"):"";
  gender=localStorage.getString("gender")!=null?localStorage.getString("gender"):"";
  yob=localStorage.getString("yob")!=null?localStorage.getString("yob"):"";
  gname=localStorage.getString("gname")!=null?localStorage.getString("gname"):"";
  house=localStorage.getString("house")!=null?localStorage.getString("house"):"";
  lm=localStorage.getString("lm")!=null?localStorage.getString("lm"):"";
  vtc=localStorage.getString("vtc")!=null?localStorage.getString("vtc"):"";
  po=localStorage.getString("po")!=null?localStorage.getString("po"):"";
  dist=localStorage.getString("dist")!=null?localStorage.getString("dist"):"";
  state=localStorage.getString("state")!=null?localStorage.getString("state"):"";
  pc=localStorage.getString("pc")!=null?localStorage.getString("pc"):"";
  print("........>>>>>>>>>>>>>>>>>>"+age+","+fever+","+tmmpa+","+tmmpb+","+tmmpc+","+tmmpd+","+tmmpe);
  await insert2db();
}
initShared();
  }
  Future<void> insert2db() async {
    print("ENCODED-------"+json.encode(tmmpa));


    var data = {"aadhar":uid,"name":name,"phone":phone,"gender":gender,"yob":yob,"gname":gname,"house":house,"lm":lm,"vtc":vtc,"po":po,"dist":dist,"state":state,"pc":pc,"age":age,"fever":fever,"tmmpa":json.encode(tmmpa),"tmmpb":json.encode(tmmpb),"tmmpc":json.encode(tmmpc),"tmmpd":json.encode(tmmpd),"tmmpe":json.encode(tmmpe)};
    print("DATA========"+data.toString());
    var url = "http://arkroot.com/covid/disease.php";

    http.Response response = await http
        .post(url,
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: data,
        encoding: Encoding.getByName("utf-8"))
        .then((var response) {
          print("JIS---===-=-=-=-===-=-=-=-=-=-"+response.body.toString());
          var dat = jsonDecode(response.body);
          for (int i = 0; i < dat.length; i++) {
            result=dat[i]["result"];
            score=dat[i]["score"];
            if(result=="High"){
              loadMusic();
            }else if(result=="Medium"){
              loadMusicm();
            }else if(result=="Low"){
              loadMusicl();
            }

            setState(() {

            });
          }

    });

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Stack(
        children: <Widget>[
      Column(
      mainAxisAlignment: MainAxisAlignment.center,

        children: <Widget>[
          Expanded(
              child: Image.asset(
                '',
                fit: BoxFit.cover,
                width: double.infinity,
              )),
        ],
      ), Padding(
        padding: const EdgeInsets.all(10.0),
        child: Center(
        child: Card(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(padding: EdgeInsets.only(top: 8)),
              Text(
                "RESULTS",
                style: TextStyle(color: Colors.blue,fontSize: 30.0, fontWeight: FontWeight.w900),
              ),
              Padding(padding: EdgeInsets.only(top: 20)),
               Center(
                 child: Column(
                   children: <Widget>[

                     (result=="High")?(Text("STATUS : "+result, style: TextStyle(fontSize: 25.0,color:Colors.red))):( (result=="Medium")?(Text("STATUS : "+result, style: TextStyle(fontSize: 25.0,color:Colors.orange))):(Text("STATUS : "+result, style: TextStyle(fontSize: 25.0,color:Colors.green)))),
                    Padding(padding: EdgeInsets.only(top:10.0),),
                     Text("Score from ML : "+((score/35)*100).toStringAsExponential(3).toString(), style: TextStyle(fontSize: 25.0,color:Colors.red))
                   ],
                 ),
               )


            ],
          ),
        ),
            ),
      ),])
    );


}
  Future _validate() async{
    if(fever==""){
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red
      );


    }
    else {

localStorage.setString("tmmpe", tmpArray.toString());

Navigator.of(context).pushReplacementNamed('/chath');


    }
  }

}
var tmpArray = [];
class CheckboxWidget extends StatefulWidget {
  @override
  CheckboxWidgetState createState() => new CheckboxWidgetState();
}

class CheckboxWidgetState extends State {

  Map<String, bool> values = {
    'Improved': false,
    'No Change': false,
    'Worsened': false,
    'Worsened Considerebely': false,
  };



  getCheckboxItems(){

    values.forEach((key, value) {
      if(value == true)
      {
        fever="true";
        tmpArray.add(key);
      }
    });

    // Printing all selected items on Terminal screen.
    print(tmpArray);
    // Here you will get all your selected Checkbox items.

    // Clear array after use.
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Column (children: <Widget>[

      RaisedButton(
        child: Text(" Get Selected Checkbox Items ", style: TextStyle(fontSize: 18),),
        onPressed: getCheckboxItems,
        color: Colors.deepOrange,
        textColor: Colors.white,
        splashColor: Colors.grey,
        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
      ),

      Expanded(
        child :
        ListView(
          children: values.keys.map((String key) {
            return new CheckboxListTile(
              title: new Text(key),
              value: values[key],
              activeColor: Colors.pink,
              checkColor: Colors.white,
              onChanged: (bool value) {
                setState(() {
                  values[key] = value;
                });
              },
            );
          }).toList(),
        ),
      ),]);
  }
}





