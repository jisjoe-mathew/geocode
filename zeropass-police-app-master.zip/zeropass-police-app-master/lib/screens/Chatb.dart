import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropaas/screens/raised_gradient_button.dart';

class Chatb extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Flutter Demo Home Page');
  }
}
SharedPreferences localStorage;
enum PatientGender { Normal, Fever, High }
PatientGender _patientGender = PatientGender.Normal;
String fever="Normal";
class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();
  TextEditingController age=new TextEditingController();
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    player = await cache.play("mp3/c3.mp3");
  }
  @override
  void initState() {
    super.initState();
    loadMusic();
initShared() async {
  localStorage = await SharedPreferences.getInstance();
}
initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        centerTitle: true,
        title: Text('Voice Assistant'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            player?.stop();
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
          child:
          Stack(
            children: <Widget>[
          Column(
          mainAxisAlignment: MainAxisAlignment.center,

            children: <Widget>[
              Flexible(

                  child: Container(
                    height: 600,
                    child: Image.network(
                      'https://image.freepik.com/free-vector/vector-illustration-man-chatting-walking-flat-style_19361-41.jpg',
                      fit: BoxFit.cover,
                      height: 100,
                      width: double.infinity,
                    ),
                  )),
            ],
          ),
          Center(
          child: Padding(
          padding: const EdgeInsets.all(10.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
        Text(
        "Please select your body Temperature",
        style: TextStyle(color: Colors.grey[700],fontSize: 18.0, fontWeight: FontWeight.w800),
      ),
      Padding(padding: EdgeInsets.only(top: 12)), Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(padding: EdgeInsets.only(top: 8)),
            Padding(padding: EdgeInsets.only(top: 8)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Radio(
                  value: PatientGender.Normal,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="Normal";
                    });
                  },
                ),
                Text(
                  'Normal',
                  style: new TextStyle(fontSize: 16.0),
                ),
                Radio(
                  value: PatientGender.Fever,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="Fever (98-102 F)";
                    });
                  },
                ),
                Text(
                  'Fever',
                  style: new TextStyle(
                    fontSize: 16.0,
                  ),
                ),
                Radio(
                  value: PatientGender.High,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="High Fever";
                    });
                  },
                ),
                Text(
                  'High Fever >102 F',
                  style: new TextStyle(fontSize: 16.0),
                ),
              ],
            ),

            SizedBox(
              height: 70,
            ),
            RaisedGradientButton(
              child: Text('Next',
                style: TextStyle(color: Colors.white),
              ),

              gradient: LinearGradient(
                colors: <Color>[Colors.purple[700], Colors.purple[300]],
              ),
              width: MediaQuery.of(context).size.width/1.2,
              height: 60,
              borderRadius: 30,
              onPressed: _validate,
            )
          ],
        ),
      )]),))]))
    );
  }
  Future _validate() async{
    if(fever==""){
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red
      );


    }
    else {

localStorage.setString("fever", fever.toString());
player?.stop();
Navigator.of(context).pushReplacementNamed('/chatc');


    }
  }
}