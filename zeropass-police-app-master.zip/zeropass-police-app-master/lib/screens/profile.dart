import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Profile extends StatefulWidget {

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  String name ="" ;

  String stationName="" ;

  String district ="";

  String rank="";

 Future fetchStoredata() async
  {
    SharedPreferences prefs = await SharedPreferences.getInstance();
   name = prefs.getString('Name');
   stationName = prefs.getString('StaionName');
   district = prefs.getString('District');

    rank = prefs.getString('Taluk');
print(rank);
setState(() {

});
  }


  @override
  void initState() {
    super.initState();
    fetchStoredata();

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Dashboard'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(

            bottom: Radius.circular(20),

          ),
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,

        children: <Widget>[

          SizedBox(
            height: 30,
          ),
          Center(
            child: Container(
              width:350,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.purple[700], Colors.indigoAccent[100]]

                    ),
                    borderRadius: BorderRadius.all(Radius.circular(20))

                ),
                child: Container(
                  width: double.infinity,
                  height: 350.0,
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        CircleAvatar(
                          backgroundImage: NetworkImage(
                            "https://w7.pngwing.com/pngs/7/618/png-transparent-man-illustration-avatar-icon-fashion-men-avatar-face-fashion-girl-heroes.png",
                          ),
                          radius: 50.0,
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          "$name",
                          style: TextStyle(
                            fontSize: 22.0,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Card(
                          margin: EdgeInsets.symmetric(horizontal: 10.0,vertical: 5.0),
                          clipBehavior: Clip.antiAlias,
                          color: Colors.white,
                          elevation: 5.0,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 22.0),
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: Column(

                                    children: <Widget>[
                                      Text(
                                        "Taluk",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 22.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                      Text(
                                        "$rank",
                                        style: TextStyle(
                                          fontSize: 15.0,
                                          color: Colors.black54,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: Column(

                                    children: <Widget>[
                                      Text(
                                        "Station",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 22.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                      Text(
                                        "$stationName",
                                        style: TextStyle(
                                          fontSize: 15.0,
                                          color: Colors.black54,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: Column(

                                    children: <Widget>[

                                      Text(
                                        "District",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 22.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                      Text(
                                        "$district",
                                        style: TextStyle(
                                          fontSize: 15.0,
                                          color: Colors.black54,
                                        ),
                                      )
                                    ],
                                  ),
                                ),

                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                )
            ),
          ),

          SizedBox(
            height: 20.0,
          ),

        ],
      ),
    );
  }
}
