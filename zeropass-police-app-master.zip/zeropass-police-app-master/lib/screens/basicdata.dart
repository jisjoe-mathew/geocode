import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropaas/widgets/PhoneRegField.dart';
import '../Animations/Fade.dart';
import '../screens/homepage.dart';
import 'signup.dart';
import '../models/designation.dart';

class BasicDataPage extends StatefulWidget {

  @override
  _BasicDataPageState createState() => _BasicDataPageState();
}


class _BasicDataPageState extends State<BasicDataPage> {

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  final databaseReference = FirebaseDatabase.instance.reference();


  final _formKey = GlobalKey<FormState>();

  var lat;
  var lng;
  String fcmtoken;
  String taluk;
  String officerName;
  String address;
  String stationName;
  String email;
  String designation;
  String district;
  String pincode;
  Designations selectedUser;


  List<Designations> users = <Designations>[
    const Designations(
        ' Constable',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'Head Constable',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'ASI',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'SI',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'CI',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'DYSP',
        Icon(
          Icons.star,
          color: Colors.grey,
        )),
    const Designations(
        'SP',
        Icon(
          Icons.star,
          color: Colors.grey,
        ))
  ];


  //shared
  _storeSignUpData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
   await prefs.setString('Name', officerName);
   await  prefs.setString("Email", email);
   await prefs.setString("Address", address);
   await prefs.setString("Designation", selectedUser.name);
   await prefs.setString("StaionName", stationName);
   await prefs.setString("Taluk", taluk);
   await prefs.setString("District", district);
   await prefs.setString("TokenID", fcmtoken);


    print('stored successfully');
  }

  _registerToken() {
    _firebaseMessaging.getToken().then((token) {
      print(token);

    fcmtoken = token;
    });
  }


  //geo
  Future<String> _getCoordinatesData() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    lat = position.latitude;
    lng = position.longitude;


    if(position == null)
      {
      _showDialog();
      }
    _getJSONData(lat, lng);

  }


   _uploadSignUpData()
   {
     databaseReference.child("Regions/$district/$taluk/PoliceStations/$stationName/Officers/$officerName").set({
       'Name': '$officerName',
       'Address': '$officerName',
       'StationName':'$stationName',
       'Email': "$email",
       'Designation': '$selectedUser',
       'Token': '$fcmtoken'
     });

     databaseReference.child("Regions/$district/$taluk").set({
       'Token' : '$fcmtoken',
     });
   }


  // toms
  Future<String> _getJSONData(double latitudess, double longitudess) async {
    var response = await http.get(
        "https://api.tomtom.com/search/2/reverseGeocode/$latitudess%2C$longitudess.json?key=W992tkrTvKiv0nidyYUfYP6wymvhTiNb");
    print(response.body);
    var loca = response.body;
    var parsedJson = json.decode(response.body);
    taluk = parsedJson["addresses"][0]["address"]["municipality"];
    district = parsedJson["addresses"][0]["address"]["countrySecondarySubdivision"];

    if (taluk != null) {}
    print(taluk);
    print(district);
  }

  @override
  void initState() {
    super.initState();
    _registerToken();
    _getCoordinatesData();
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, colors: [
              Colors.purple[900],
              Colors.purple[800],
              Colors.purple[400]
            ])),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(
                      height: 90,
                    ),
                    Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          FadeAnimation(
                              1,
                              Text(
                                "Registrations",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 40),
                              )),
                          SizedBox(
                            height: 10,
                          ),
                          FadeAnimation(
                              1.3,
                              Text(
                                "Welcome To ZeroPass",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18),
                              )),
                        ],
                      ),
                    ),
                    SizedBox(height: 30),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(60),
                                topRight: Radius.circular(60))),
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: EdgeInsets.all(30),
                            child: Column(
                              children: <Widget>[
                                SizedBox(
                                  height: 30,
                                ),
                                FadeAnimation(
                                  1.4,
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Color.fromRGBO(
                                                  115, 15, 27, .3),
                                              blurRadius: 20,
                                              offset: Offset(0, 10))
                                        ]),
                                    child: Form(
                                      key: _formKey,
                                      child: Column(
                                        children: <Widget>[
                                          Container(
                                            padding: EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                                border: Border(
                                                    bottom: BorderSide(
                                                        color:
                                                            Colors.grey[200]))),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                icon: Icon(
                                                  Icons.info,
                                                  size: 20,
                                                ),
                                                labelText: 'Name',
                                              ),
                                              keyboardType: TextInputType.text,
                                              validator: (value) {
                                                if (value.isEmpty) {
                                                  return 'Enter your Name';
                                                }
                                                return null;
                                              },
                                              onChanged: (value) {
                                                officerName = value;
                                              },
                                            ),
                                          ),
                                          Container(
                                              padding: EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Colors
                                                              .grey[200]))),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  icon: Icon(
                                                    Icons.mail,
                                                    size: 20,
                                                  ),
                                                  labelText: 'Email',
                                                ),
                                                keyboardType:
                                                    TextInputType.text,
                                                validator: (value) {
                                                  if (value.isEmpty) {
                                                    return 'Enter email';
                                                  }
                                                  return null;
                                                },
                                                onChanged: (value) {
                                                  email = value;
                                                },
                                              )),
                                          Container(
                                              padding: EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Colors
                                                              .grey[200]))),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  icon: Icon(
                                                    Icons.location_on,
                                                    size: 20,
                                                  ),
                                                  labelText: 'Address',
                                                ),
                                                keyboardType:
                                                    TextInputType.text,
                                                validator: (value) {
                                                  if (value.isEmpty) {
                                                    return 'Enter your Address';
                                                  }
                                                  return null;
                                                },
                                                onChanged: (value) {
                                                  address = value;
                                                },
                                              )),
                                          Container(
                                              padding: EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Colors
                                                              .grey[200]))),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  icon: Icon(
                                                    Icons.my_location,
                                                    size: 20,
                                                  ),
                                                  labelText: 'Station Name',
                                                ),
                                                keyboardType:
                                                    TextInputType.text,
                                                validator: (value) {
                                                  if (value.isEmpty) {
                                                    return 'Enter your Station Name';
                                                  }
                                                  return null;
                                                },
                                                onChanged: (value) {
                                                  stationName = value;
                                                },
                                              )),
                                          Container(
                                            padding: EdgeInsets.all(5),
                                            decoration: BoxDecoration(
                                                border: Border(
                                                    bottom: BorderSide(
                                                        color:
                                                            Colors.grey[200]))),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Text(
                                                  "Designations",
                                                  style: TextStyle(
                                                      color: Colors.grey[600]),
                                                ),
                                                SizedBox(
                                                  width: 30,
                                                ),
                                                DropdownButton<Designations>(
                                                  hint: Text("Select Rank"),
                                                  value: selectedUser,
                                                  onChanged:
                                                      (Designations Value) {

                                                    setState(() {
                                                      selectedUser = Value;

                                                      print(selectedUser.name);
                                                    });
                                                  },
                                                  items: users
                                                      .map((Designations user) {
                                                    return DropdownMenuItem<
                                                        Designations>(
                                                      value: user,
                                                      child: Row(
                                                        children: <Widget>[
                                                          user.icon,
                                                          SizedBox(
                                                            width: 10,
                                                          ),
                                                          Text(
                                                            user.name,
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  }).toList(),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 40,
                                ),
                                FadeAnimation(
                                    1.6,
//
                                    ButtonTheme(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(30)),
                                      child: RaisedButton(
                                        padding:
                                            EdgeInsets.fromLTRB(60, 17, 60, 17),
                                        color: Colors.purple[800],
                                        onPressed: () async {
                                          if (_formKey.currentState
                                              .validate() && Position !=null) {

                                            _uploadSignUpData();
                                            _storeSignUpData();



                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SignUp()));
                                          }
                                        },
                                        child: Text(
                                          "Register",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    )),
                                SizedBox(
                                  height: 50,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  void _showDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20.0))),
          title: new Text("Location Permission"),

          content: new Text("Please switch on location"),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            new FlatButton(
              child: new Text("Close" ,style: TextStyle(color: Colors.purple[700]),),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],

        );
      },
    );
  }
}
