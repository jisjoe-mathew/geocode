import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeropaas/screens/raised_gradient_button.dart';

class Chatintro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Chat Home Page');
  }
}
SharedPreferences localStorage;
class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  AudioPlayer player = AudioPlayer();
  AudioCache cache = AudioCache();
  FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController age=new TextEditingController();
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    player = await cache.play("mp3/c1.mp3");
  }
  @override
  void initState() {
super.initState();
loadMusic();
initShared() async {
  localStorage = await SharedPreferences.getInstance();
}
initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar:  AppBar(
          centerTitle: true,
          title: Text('Voice Assistant'),
          backgroundColor: Colors.purple[800],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(20),
            ),
          ),
        ),
      body: Center(
        child:
        Stack(
        children: <Widget>[
        Column(
        mainAxisAlignment: MainAxisAlignment.center,

        children: <Widget>[
        Expanded(
        child: Image.asset(
        'assets/home_bg.png',
        fit: BoxFit.cover,
        width: double.infinity,
    )),
    ],
    ),
    Center(
    child: Padding(
      padding: const EdgeInsets.all(10.0),
      child: Center(
        child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[


                Image.network("https://i.pinimg.com/originals/08/e7/ec/08e7ec0f84233b37ac26e920bc60ec57.gif"),
                Center(
                  child: Text(
                    "PLEASE RAISE VOLUME LEVELS TO LISTEN",
                    style: TextStyle(color: Colors.grey[500],fontSize: 18.0, fontWeight: FontWeight.w800),
                  ),
                ),
                Padding(padding: EdgeInsets.only(top: 12)),
                Text(
                  "DISCLAIMER",
                  style: TextStyle(color: Colors.red,fontSize: 25.0, fontWeight: FontWeight.w800),
                ),
                Padding(padding: EdgeInsets.only(top: 12)),

                Padding(
                  padding: const EdgeInsets.only(top:12.0),
                  child: RaisedGradientButton(
                    child: Text('Next',
                      style: TextStyle(color: Colors.white),
                    ),

                    gradient: LinearGradient(
                      colors: <Color>[Colors.purple[700], Colors.purple[300]],
                    ),
                    width: MediaQuery.of(context).size.width/1.2,
                    height: 60,
                    borderRadius: 30,
                    onPressed: _validate,
                  ),
                )
              ],
            ),
      ),
    ),
      ),]))
    );
  }
  Future _validate() async{
    if(age.text!=""){
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red
      );


    }
    else {

localStorage.setString("age", age.text.toString());
player?.stop();
Navigator.of(context).pushReplacementNamed('/chata');


    }
  }
}