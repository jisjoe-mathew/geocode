import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';



class BreakNotifications extends StatefulWidget {
  @override
  _BreakNotificationsState createState() => _BreakNotificationsState();
}




class _BreakNotificationsState extends State<BreakNotifications> {


 Map notificationData ;
 String taluk;
  String district;
  String tokenID;

  List keys = [];
  List values = [];

  final databaseReference = FirebaseDatabase.instance.reference();


_fetchStorageData()async
{
  SharedPreferences prefs = await SharedPreferences.getInstance();

   taluk = prefs.getString('Taluk');
  district = prefs.getString('District');

//  print(district);

_getBreakData();
}

_getBreakData()
{
  databaseReference.child("Regions/$district/$taluk/Breaks/ContainmentBreak").onValue.listen((event) {
   print(event.snapshot.value);
   notificationData = event.snapshot.value ;

   notificationData.forEach((k, v) {
     keys.add(k);
     values.add(v);
     setState(() {});
   });

   print(notificationData.length);
   print(keys);
//   print(values);

  });


}

 void initState() {
   super.initState();
_fetchStorageData();

 }



  @override
  Widget build(BuildContext context) {



    return Scaffold(
      appBar:  AppBar(
        centerTitle: true,
        title: Text('Notifications'),
        backgroundColor: Colors.purple[800],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
      body:     new ListView.builder
        (
          itemCount: values.length,

          itemBuilder: (BuildContext ctxt, int Index) {


            return Card(
              child: Padding(

                padding: const EdgeInsets.all(20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    new Text(values[Index]["Mob"] , style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),

                    IconButton(icon: Icon(Icons.video_call, size: 40,color: Colors.green[300],),)
                  ],
                ),
              ),
            );


          }
      ),
    );
  }
}
