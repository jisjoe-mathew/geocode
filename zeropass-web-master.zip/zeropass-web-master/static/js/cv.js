const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
var tokArray=[];
var dataSet=[];
db.ref("Regions/Thrissur/Thrissur/Breaks/QuarantineBreak").once('value')
.then(function(snapshot) {  
  snapshot.forEach(function(child) {
    tokArray.push(child.key);  
  })   
}).then(()=>{
for(var i in tokArray){
    db.ref(`Regions/Thrissur/Thrissur/Users/${tokArray[i]}`).once("value")
    .then((snap)=>{
      var data=snap.val();
      console.log(data);
      dataSet.push([data.Name,data.Address,data.Mob,data.AadharID,data.Quarantine,`<form id=${data.Mob} onsubmit="mapfunction()"><input name="lat" type="text" value=${data.Lat} style="display: none;"/><input name="long" type="text" value=${data.Long} style="display: none;"/><input name="token" type="text" value=${data.Mob} style="display: none;"/><input type="submit" name="button" value="view in map" class="map-btn"/></form>`]);          
    });
  }
  console.log(dataSet)
  setTimeout(table,1000);
});
function table(){
  $('#dataTable').DataTable({data: dataSet,destroy: true,dom: 'lBfrtip',buttons: ['excelHtml5']   
  });
}

function mapfunction() {
  event.preventDefault(); // prevents the form from reloading the page
  const form = event.currentTarget;
  // your logic goes here
  var modal = document.getElementById("myModal");
  var span = document.getElementsByClassName("map-close")[0];
  modal.style.display = "block";
  span.onclick = function() {
  modal.style.display = "none";
  }
  var greenIcon = new L.Icon({
    iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  var lats=[];var longs=[];var times=[];
  var DbData=db.ref(`Regions/Thrissur/Thrissur/Breaks/QuarantineBreak`).orderByChild("Mob").equalTo(form.token.value);
  DbData.once("value",snap=>{
    var test=snap.val();
    for (var key in test) {
    for(var key2 in test[key]){
      times.push(key2);
      if(!test[key][key2].Lat || !test[key][key2].Long)
        continue;
      lats.push(test[key][key2].Lat);
      longs.push(test[key][key2].Long);
    }
  } console.log(lats,longs,times)
 }).then(()=>{
    $("#vcount").html(lats.length);
    for(i=0;i<lats.length;i++){
      L.marker([lats[i],longs[i]]).addTo(map).bindPopup(times[i]);
    }
 })
  var map = L.map('map').setView([form.lat.value, form.long.value],13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
  L.marker([form.lat.value, form.long.value],{icon:greenIcon}).addTo(map)
    .bindPopup('<b>Home Location</b>')
    .openPopup();
}