const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };

var map = L.map('map');
const dstname=document.getElementById("district").value;
const taluk=document.getElementById("taluk").value;
const type=document.getElementById("type").value;

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
var dataSet=[];
db.ref(`Regions/${dstname}/${taluk}/${type}`).once('value')
.then(function(snapshot) {  
  snapshot.forEach(function(child) {
    db.ref(`Regions/${dstname}/${taluk}/Users/${child.key}`).once("value")
    .then((snap)=>{
      dataSet.push([snap.val().Name,snap.val().Address,snap.val().Mob,snap.val().AadharID,snap.val().Quarantine,child.numChildren()-1,`<form id=${snap.val().Mob} onsubmit="mapfunction()"><input name="lat" type="text" value=${snap.val().Lat} style="display: none;"/><input name="long" type="text" value=${snap.val().Long} style="display: none;"/><input name="token" type="text" value=${snap.val().Mob} style="display: none;"/><input type="submit" name="button" value="view in map" class="map-btn"/></form>`]);          
    });
  })  
  setTimeout(table,1000);  
});
function table(){
  $('#dataTable').DataTable({data: dataSet,destroy: true,dom: 'lBfrtip',buttons: ['excelHtml5']   
  });
}

function mapfunction() {
  event.preventDefault(); // prevents the form from reloading the page
  const form = event.currentTarget;
  var modal = document.getElementById("myModal");
  var span = document.getElementsByClassName("map-close")[0];
  modal.style.display = "block";
  span.onclick = function() {
  modal.style.display = "none";
  }
  var greenIcon = new L.Icon({
    iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
  var lats=[];var longs=[];var times=[];
  var DbData=db.ref(`Regions/${dstname}/${taluk}/${type}`).orderByChild("Mob").equalTo(form.token.value);
  DbData.once("value",snap=>{
    var test=snap.val();
    for (var key in test) {
    for(var key2 in test[key]){
      if(!test[key][key2].Lat || !test[key][key2].Long)
        continue;
      lats.push(test[key][key2].Lat);
      longs.push(test[key][key2].Long);
      times.push(test[key][key2].Time);
    }
  }
 }).then(()=>{
    $("#vcount").html(lats.length);
    for(i=0;i<lats.length;i++){
      L.marker([lats[i],longs[i]]).addTo(map).bindPopup(times[i]);
    }
 })
  map.setView([form.lat.value, form.long.value],13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
  L.marker([form.lat.value, form.long.value],{icon:greenIcon}).addTo(map)
    .bindPopup('<b>Home Location</b>')
    .openPopup();
}
