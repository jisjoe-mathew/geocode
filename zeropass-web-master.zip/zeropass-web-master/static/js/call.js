const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const dstname=document.getElementById("district").value;
const taluk=document.getElementById("taluk").value;

function sendNotification() {
    event.preventDefault();  
    const notificationMessage = document.getElementById('notification-message').value;
    if ( !notificationMessage) return;
    db.ref(`/JitsiNotificationsToOfficers`).push({
        SenderDistrict:dstname,
        SenderTaluk: taluk,
        RoomID:notificationMessage
    }).then(()=>{
        document.getElementById("call").innerHTML = "";
        alert("Sucessfully established connection");
        var domain = "meet.jit.si";
        var options = {
            roomName: notificationMessage,
            width: 1020,
            height: 600,
            parentNode: document.getElementById("call"),
            configOverwrite: {},
            interfaceConfigOverwrite: {
                filmStripOnly: true
            }
        }
        var api = new JitsiMeetExternalAPI(domain, options);
    })
    .catch(()=>{alert("Unable to place call. Please try again.")})
}

