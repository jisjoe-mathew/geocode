const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const dstname=document.getElementById("district").value;
const taluk=document.getElementById("taluk").value;

function sendNotification() {
    event.preventDefault();  
    const notificationMessage = document.getElementById('notification-message').value;
    const notificationCat = document.getElementById('cat').value;
    if ( !notificationMessage || !notificationCat) return;
    db.ref(`/WebNotifications`).push({
        SenderDistrict:dstname,
        SenderTaluk: taluk,
        Message:notificationMessage,
        Category:notificationCat
    }).then(()=>{document.getElementById('notification-message').value = "";alert("Sucessfully sent")})
      .catch(()=>{alert("Unable to send. Please try again.")})
}


