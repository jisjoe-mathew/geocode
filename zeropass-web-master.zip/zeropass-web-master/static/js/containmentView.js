const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };

const dstname=document.getElementById("district").value;
const taluk=document.getElementById("taluk").value;

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

var map = L.map('map').setView([10.8505, 76.2711],10);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>contributors'
}).addTo(map);

var pointArray=[];
var nameArray=[];

db.ref(`Regions/${dstname}/${taluk}/Polygon`).once('value')
.then(function(snapshot) {  
  snapshot.forEach(function(child) {
    nameArray.push(child.key);
    for(i in child.val()){
        var u=[];
        for(var j=0;j<child.val().length;j++){
            u.push(child.val()[j].reverse());             
        } 
    }pointArray.push(u);
  });  
})
.then(()=>{
   for(var i=0;i<pointArray.length;i++){
        var polygon=L.polygon(pointArray[i],{
         color: 'red',
         fillColor: '#f03',
         fillOpacity: 0.5,
        }).addTo(map)
        .bindPopup(nameArray[i])
        .openPopup();
   }
}).catch(error=>{alert("Error occured while loading zones");})



$("#zn").on("keyup", function(){
    if($(this).val() != ""){
        $("#az").removeAttr("disabled");
    } else {
        $("#az").attr("disabled", "disabled");
    }
});

function func(){
    event.preventDefault();
    var form=$("#mapform");
    $.ajax({
      type: 'POST',
      url: form.attr('action'),
      data:form.serialize(),
    })
    .done(function(data){
      alert(data);
      window.location.reload();
    })
    .fail(function(err){
    alert("Error occured while removing zone");
  })
}
