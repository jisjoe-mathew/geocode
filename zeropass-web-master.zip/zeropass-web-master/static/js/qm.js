const firebaseConfig = {
    apiKey: "AIzaSyAQQsaYnySLKVssnzus-D42eN9vBbgSK1Y",
    authDomain: "zeropass-24ac5.firebaseapp.com",
    databaseURL: "https://zeropass-24ac5.firebaseio.com",
    projectId: "zeropass-24ac5",
    storageBucket: "zeropass-24ac5.appspot.com",
    messagingSenderId: "204385607719",
    appId: "1:204385607719:web:2aff6af67468d14ed46e02",
    measurementId: "G-LWGMWWY0JX"
  };
const dstname=document.getElementById("district").value;
const taluk=document.getElementById("taluk").value;

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
var dataSet=[];
db.ref(`Regions/${dstname}/${taluk}/Users`).once('value')
.then(function(snap) { 
    snap.forEach(function(snapshot) {
        if(snapshot.val().Quarantine==true){
            dataSet.push([snapshot.val().Name,snapshot.val().Address,snapshot.val().Mob,snapshot.val().AadharID,snapshot.val().Quarantine,`<form id=${snapshot.val().Mob} onsubmit="logsfunction()"><input name="Status" type="text" value=2 style="display: none;"/><input name="Mob" type="text" value=${snapshot.key} style="display: none;"><input type="submit" name="button" value="Disable Quarantine" class="map-btn"style="background-color:Red!important"/></form>`,`<form id=${snapshot.val().Mob} onsubmit="changefunction()"><input name="Mob" type="text" value=${snapshot.key} style="display: none;"><input type="submit" name="button" value="View Logs" class="map-btn"style="background-color:#4e73df;!important"/></form>`]);               
        }
        else{
            dataSet.push([snapshot.val().Name,snapshot.val().Address,snapshot.val().Mob,snapshot.val().AadharID,snapshot.val().Quarantine,`<form id=${snapshot.val().Mob} onsubmit="changefunction()"><input name="Status" type="text" value=1 style="display: none;"/><input name="Mob" type="text" value=${snapshot.key} style="display: none;"/><input type="submit" name="button" value="Enable Quarantine" class="map-btn"style="background-color:Green!important"/></form>`," "]);               
        }
    })
})
.then(()=>{
    $('#dataTable').DataTable({data: dataSet,destroy: true,dom: 'lBfrtip',buttons: ['excelHtml5']});
});

function changefunction() {
    event.preventDefault(); // prevents the form from reloading the page
    const form = event.currentTarget;
    if(form.Status.value==1){
        db.ref(`Regions/${dstname}/${taluk}/Users/${form.Mob.value}`).once("value",function(snapshot) {
              snapshot.ref.child("Quarantine").set(true);})
          .then(()=>{
            alert("Sucessfully enabled quarantine mode");
          })
          .catch(()=>{alert("Failed to enable quarantine mode")}) 
    }
    else{
        db.ref(`Regions/${dstname}/${taluk}/Users/${form.Mob.value}`).once("value",function(snapshot) {
            snapshot.ref.child("Quarantine").set(false);})
          .then(()=>{
            alert("Sucessfully disabled quarantine mode");
          })
          .catch(()=>{alert("Failed to disable quarantine mode")}) 
    }
}


function changefunction() {
    event.preventDefault();
    const form = event.currentTarget;
    var modal = document.getElementById("myModal");
    var span = document.getElementsByClassName("map-close")[0];
    modal.style.display = "block";
    span.onclick = function() {
    modal.style.display = "none";
    }
    var table = document.querySelector('#complainttable tbody');
    while(table.hasChildNodes()) {
        table.removeChild(table.firstChild);
    }
    var DbData=db.ref(`Regions/${dstname}/${taluk}/QuarantineLogs/${form.Mob.value}`);
    DbData.once("value",snap=>{
    snap.forEach(function(snapshot){
        var row = table.insertRow(-1);
        cell = row.insertCell(-1);
        cell.innerHTML = snapshot.val();
    })
   });
}