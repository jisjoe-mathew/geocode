const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);

exports.sendNotificationToTopic = functions.database.ref('/WebNotifications/{notificationId}').onWrite(async (change, context) =>{

    const SenderDistrict = change.after.child("SenderDistrict").val();   
    const SenderTaluk= change.after.child("SenderTaluk").val(); 
    const Message = change.after.child("Message").val(); 
    const Cat = change.after.child("Category").val();     

    const payload = {
        notification: {
          title: `New Message from ${SenderTaluk} Taluk Administration`,
          body: Message
        }
    }  

    const tokens = [];
    if(Cat=="containment"){
        return admin.database().ref(`Regions/${SenderDistrict}/${SenderTaluk}/Users`).orderByChild("Containment").equalTo(true).once('value')
        .then((data)=> {       
        data.forEach((child)=>{
        tokens.push(child.key);
        })    
        return admin.messaging().sendToDevice(tokens, payload);
        })
        .catch(()=>{console.log("Error");})
    }
    else if(Cat=="quarantine"){
        return admin.database().ref(`Regions/${SenderDistrict}/${SenderTaluk}/Users`).orderByChild("Quarantine").equalTo(true).once('value')
        .then((data)=> {       
        data.forEach((child)=>{
        tokens.push(child.key);
        })    
        return admin.messaging().sendToDevice(tokens, payload);
        })
        .catch(()=>{console.log("Error");})
    }
    else{
        return admin.database().ref(`Regions/${SenderDistrict}/${SenderTaluk}/Users`).once('value')
        .then((data)=> {       
        data.forEach((child)=>{
        tokens.push(child.key);
        })    
        return admin.messaging().sendToDevice(tokens, payload);
        })
        .catch(()=>{console.log("Error");})
    }
});