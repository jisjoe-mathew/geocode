const bodyParser = require("body-parser");
const express = require("express");
const hbs = require("hbs");
const path = require('path');
var admin = require("firebase-admin");

var serviceAccount = require("./serviceAccountKey.json");
// const { json } = require("body-parser");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://zeropass-24ac5.firebaseio.com"
});

const db = admin.database();
const app = express();

app.set('view engine','hbs');
app.use(express.static(path.join(__dirname + '/static')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


app.get("/login", function (req, res) {
  res.render("login.hbs");
});


app.get("/", function (req, res) {
  res.render("index.hbs");
});

app.post("/viewTaluks",function(req,res){
  tokArray.length = 0;
  dstname=req.body.district;
  db.ref(`Regions/${dstname}`).once('value')
  .then(function(snapshot) {  
    snapshot.forEach(function(child) {
      if(child.key!="PoliceLocations")
      tokArray.push(child.key);    
    });  
    res.status(200).send(JSON.stringify(tokArray));
  })
  .catch(error=>{res.status(500).send("Error occured while getting Taluks");})  
})

app.post("/viewDetails",function(req,res){
  taluk=req.body.taluk;
  getDashDetails(taluk, function(){
    return res.json({ cv: `${count.cv}`,qv: `${count.qv}`,cr: `${count.cr}`,zt: `${count.zt}`,co: `${count.co}`
   });
  });
});

app.get("/registeredCases", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("registeredCases.hbs",{dstname:dstname,taluk:taluk,type:"CasesRegistered"});  
});

app.get("/containmentViolations", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("containmentViolations.hbs",{dstname:dstname,taluk:taluk,type:"Breaks/ContainmentBreak"});
});
app.get("/quarantineViolations", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("quarantineViolations.hbs",{dstname:dstname,taluk:taluk,type:"Breaks/QuarantineBreak"});
});

app.get("/addContainment", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("addContainment.hbs");
});

app.post("/add",function(req,res){
  db.ref(`Regions/${dstname}/${taluk}/Polygon/${req.body.zoneName}`).set(
    JSON.parse(req.body.coordinates)    
  ).then(()=>{
    res.send("Sucessfully added zone");
  })
  .catch(error=>{res.send("Error occured while adding zone");})  
});

app.get("/viewContainment", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("viewContainment.hbs",{dstname:dstname,taluk:taluk});
});

app.post("/delete",function(req,res){
  db.ref(`Regions/${dstname}/${taluk}/Polygon/${req.body.zoneName}`).remove()
  .then(()=>{
    res.send("Sucessfully removed zone");
  })
  .catch(error=>{res.send("Error occured while removing zone");})  
});

app.get("/quarantineMode", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("quarantineMode.hbs",{dstname:dstname,taluk:taluk});
});

app.get("/publishAlert", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("publishAlert.hbs",{dstname:dstname,taluk:taluk});
});

app.get("/complaints", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("complaints.hbs",{dstname:dstname,taluk:taluk});
});

app.get("/meet", function (req, res) {
  if(!taluk){
    return res.send("Please select a location from Dashboard")
  }
  res.render("meet.hbs",{dstname:dstname,taluk:taluk});
});

app.get("/viewReceipt", function (req, res) {
  res.render("viewReceipt.hbs");
});

app.post("/receipt",function(req,res){
  db.ref(`Cases/${req.body.VechicleNumber}`).once("value")
  .then((snap)=>{
    var details=snap.val().Details;
    var amount=snap.val().Amount;
    var vno=req.body.VechicleNumber;
    var time=snap.val().Time;
    res.render("receipt.hbs",{details:details,amount:amount,vno:vno,time:time});
  })
    .catch(()=>{
      res.send("Cannot find details");
    })
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Listening on http://localhost:${PORT}`);
});
  
//var declarations

var tokArray = [];
var count={cv:"0",qv:"0",cr:"0",zt:"0",co:"0"};
var dstname;
var taluk;

// additional functions

function getDashDetails(taluk,callback){
  var a=db.ref(`Regions/${dstname}/${taluk}/`);
  a.child(`Breaks/ContainmentBreak`).once("value",snap=>{
    count.cv=snap.numChildren();
  a.child(`Breaks/QuarantineBreak`).once("value",snap=>{
      count.qv=snap.numChildren();
    });
  a.child(`CasesRegistered`).once("value",snap=>{
      count.cr=snap.numChildren();
    });
  a.child(`Complaints`).once("value",snap=>{
      count.co=snap.numChildren();
    });
  a.child(`Polygon`).once("value",snap=>{
      count.zt=snap.numChildren();
      return callback();
    })
  })  
}